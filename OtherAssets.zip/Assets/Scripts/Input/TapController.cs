using Microsoft.MixedReality.Toolkit.Input;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class TapController : MonoBehaviour, IMixedRealityFocusHandler, IMixedRealityPointerHandler
{
    public GameObject hoverObject;
    public TriageDataLoader tdl;
    public ImpactViewManager ivm;
    public TextMeshPro nameText;
    public GameObject failedJob;
    private FaultsDataLoader faultDataLoader;
    /*
    public GameObject missedJob;
    private MissedDataLoader missDataLoader;
    public GameObject toMissJob;
    private ToMissDataLoader tmDataLoader;
    */

    public void Start()
    {
        //tdl = GameObject.FindGameObjectWithTag("Triage").GetComponent<TriageDataLoader>();

        faultDataLoader = failedJob.GetComponent<FaultsDataLoader>();

        //missDataLoader = missedJob.GetComponent<MissedDataLoader>();

        //tmDataLoader = toMissJob.GetComponent<ToMissDataLoader>();
    }
    public void OnTriggerEnter(Collider other)
    {
        hoverObject.SetActive(false);
        if (other.gameObject.name == "LandmarkDock")
        {
            //Debug.Log(other.gameObject.name);
            //Debug.Log(gameObject.name);

            tdl.UpdateText(gameObject.name);
            ivm.UpdateObj(gameObject.name);
            if (this.gameObject.tag == "Failed")
            {
                nameText.text = faultDataLoader.name.text;
            }

            /*
            else if (this.gameObject.tag == "Missed")
            {
                nameText.text = missDataLoader.name.text;
            }
            else if (this.gameObject.tag == "ToMiss")
            {
                nameText.text = tmDataLoader.name.test;
            }
            */
        }
        
    }
    public void OnTriggerStay(Collider other)
    {
        hoverObject.SetActive(false);
    }

    public void OnTriggerExit(Collider other)
    {
        hoverObject.SetActive(true);
    }
    public void OnFocusEnter(FocusEventData eventData)
    {
        
        //throw new System.NotImplementedException();
    }

    public void OnFocusExit(FocusEventData eventData)
    {
        
        //throw new System.NotImplementedException();
    }

    public void OnPointerClicked(MixedRealityPointerEventData eventData)
    {

    }

    public void OnPointerDown(MixedRealityPointerEventData eventData)
    {

        //throw new System.NotImplementedException();
    }

    public void OnPointerDragged(MixedRealityPointerEventData eventData)
    {

        //throw new System.NotImplementedException();
    }

    public void OnPointerUp(MixedRealityPointerEventData eventData)
    {

        //throw new System.NotImplementedException();
    }
}

using Microsoft.MixedReality.Toolkit.Input;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HandInputController : MonoBehaviour, IMixedRealityFocusHandler, IMixedRealityPointerHandler
{
    public AppSceneManager asm;
    public void OnFocusEnter(FocusEventData eventData)
    {

        //throw new System.NotImplementedException();
    }

    public void OnFocusExit(FocusEventData eventData)
    {
        //throw new System.NotImplementedException();
    }

    public void OnPointerClicked(MixedRealityPointerEventData eventData)
    {
        //print(gameObject.name);
        if (gameObject.name == "Failed_Object")
        {
            asm.ActivateJV("Failed");
        }
        else if (gameObject.name == "Missed_Object")
        {
            asm.ActivateJV("Missed");
        }
        else if(gameObject.name == "PredictedToMiss_Object")
        {
            asm.ActivateJV("ToMiss");
        }
        //throw new System.NotImplementedException();
    }

    public void OnPointerDown(MixedRealityPointerEventData eventData)
    {

        //throw new System.NotImplementedException();
    }

    public void OnPointerDragged(MixedRealityPointerEventData eventData)
    {

        //throw new System.NotImplementedException();
    }

    public void OnPointerUp(MixedRealityPointerEventData eventData)
    {

        //throw new System.NotImplementedException();
    }
}

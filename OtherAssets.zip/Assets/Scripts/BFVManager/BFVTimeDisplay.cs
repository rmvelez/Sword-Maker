using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class BFVTimeDisplay : MonoBehaviour
{
    private float loadClock = 3f;
    
    public GameObject fullBarOne;
    public GameObject fullBarTwo;
    public GameObject fullBarThree;
    

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (loadClock <= 3f)
        {
            loadClock -= Time.deltaTime;
            fullBarOne.SetActive(true);
        }
        if (loadClock <= 2f)
        {
            fullBarTwo.SetActive(true);
        }
        if (loadClock <= 1f)
        {
            fullBarThree.SetActive(true);
        }
    }

   public void ResetTimer()
   {
        loadClock = 3f;
        DisableFullBars();
   }

   public void StopTimer()
   {
        loadClock = 0f;
   }
    
   private void DisableFullBars()
   {
       fullBarOne.SetActive(false);
       fullBarTwo.SetActive(false);
       fullBarThree.SetActive(false);
   }
   
}

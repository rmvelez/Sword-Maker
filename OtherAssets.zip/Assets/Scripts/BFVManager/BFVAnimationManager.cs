using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BFVAnimationManager : MonoBehaviour
{
    public GameObject slaCount;
    public GameObject failCount;
    public GameObject missedCount;
    public GameObject status;
    public GameObject type;
    public GameObject completedJobs;
    public GameObject predictedEndTime;
    public GameObject slaForProcessContainer;
    public GameObject predictedStartTime;
    public GameObject slaContainerStatus;
    public float seqDelay;
    public float seqDuration;
    public float easeDuration;
    public float multiplier;
    public bool flag = true;
    void Start()
    {
        AnimateBFV();
    }

    public void AnimateBFV()
    {
        if (flag)
        {
            var seq = LeanTween.sequence();
            seq.append(seqDelay);
            seq.append(LeanTween.scale(type, Vector3.one, seqDuration));
            seq.insert(LeanTween.scale(type, Vector3.one * multiplier, easeDuration).setEasePunch());
            seq.append(LeanTween.scale(slaForProcessContainer, Vector3.one, seqDuration));
            seq.insert(LeanTween.scale(slaForProcessContainer, Vector3.one * multiplier, easeDuration).setEasePunch());
            seq.append(LeanTween.scale(slaContainerStatus, Vector3.one, seqDuration));
            seq.insert(LeanTween.scale(slaContainerStatus, Vector3.one * multiplier, easeDuration).setEasePunch());
            seq.append(LeanTween.scale(predictedEndTime, Vector3.one, seqDuration));
            seq.insert(LeanTween.scale(predictedEndTime, Vector3.one * multiplier, easeDuration).setEasePunch());
            seq.append(LeanTween.scale(predictedStartTime, Vector3.one, seqDuration));
            seq.insert(LeanTween.scale(predictedStartTime, Vector3.one * multiplier, easeDuration).setEasePunch());
            seq.append(LeanTween.scale(status, new Vector3(1, 1, 1), seqDuration));
            seq.insert(LeanTween.scale(status, new Vector3(1, 1, 1) * multiplier, easeDuration).setEasePunch());



            var seq2 = LeanTween.sequence();
            seq2.append(seqDelay);
            seq2.append(LeanTween.scale(slaCount, new Vector3(3, 3, 3), seqDuration));
            seq2.insert(LeanTween.scale(slaCount, new Vector3(3, 3, 3) * multiplier, easeDuration).setEasePunch());
            seq2.append(LeanTween.scale(missedCount, new Vector3(3, 3, 3), seqDuration));
            seq2.insert(LeanTween.scale(missedCount, new Vector3(3, 3, 3) * multiplier, easeDuration).setEasePunch());
            seq2.append(LeanTween.scale(failCount, new Vector3(3, 3, 3), seqDuration));
            seq2.insert(LeanTween.scale(failCount, new Vector3(3, 3, 3) * multiplier, easeDuration).setEasePunch());
            seq2.append(LeanTween.scale(completedJobs, Vector3.one, seqDuration));
            seq2.insert(LeanTween.scale(completedJobs, Vector3.one * multiplier, easeDuration).setEasePunch());

            type.transform.localScale = Vector3.one;
            slaCount.transform.localScale = new Vector3(3, 3, 3);
        }
        else
        {
            var seq = LeanTween.sequence();
            seq.append(seqDelay);
            seq.append(LeanTween.scale(status, new Vector3(1, 1, 1) * multiplier, easeDuration).setEasePunch());
            seq.append(LeanTween.scale(type, Vector3.one * multiplier, easeDuration).setEasePunch());
            seq.append(LeanTween.scale(slaForProcessContainer, Vector3.one * multiplier, easeDuration).setEasePunch());
            seq.append(LeanTween.scale(slaContainerStatus, Vector3.one * multiplier, easeDuration).setEasePunch());
            seq.append(LeanTween.scale(predictedEndTime, Vector3.one * multiplier, easeDuration).setEasePunch());
            seq.append(LeanTween.scale(predictedStartTime, Vector3.one * multiplier, easeDuration).setEasePunch());



            var seq2 = LeanTween.sequence();
            seq2.append(seqDelay);
            seq2.append(LeanTween.scale(slaCount, new Vector3(3, 3, 3) * multiplier, easeDuration).setEasePunch());
            seq2.append(LeanTween.scale(missedCount, new Vector3(3, 3, 3) * multiplier, easeDuration).setEasePunch());
            seq2.append(LeanTween.scale(failCount, new Vector3(3, 3, 3) * multiplier, easeDuration).setEasePunch());
            seq2.append(LeanTween.scale(completedJobs, Vector3.one * multiplier, easeDuration).setEasePunch());

            status.transform.localScale = Vector3.one;
            slaCount.transform.localScale = new Vector3(3, 3, 3);

        }
        


    }
}

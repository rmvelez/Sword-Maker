using Microsoft.MixedReality.Toolkit.Input;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class BFVTapController : MonoBehaviour, IMixedRealityFocusHandler, IMixedRealityPointerHandler
{
    public SpriteRenderer innerCircle;
    public SpriteRenderer outerCircle;
    public Color orgColor;

    public void OnFocusEnter(FocusEventData eventData)
    {
        outerCircle.color = Color.green;
        innerCircle.color = Color.green;
        //throw new System.NotImplementedException();
    }

    public void OnFocusExit(FocusEventData eventData)
    {
        outerCircle.color = orgColor;
        innerCircle.color = orgColor;
        //throw new System.NotImplementedException();
    }

    public void OnPointerClicked(MixedRealityPointerEventData eventData)
    {
        outerCircle.color = Color.white;
        innerCircle.color = Color.white;
    }

    public void OnPointerDown(MixedRealityPointerEventData eventData)
    {

        //throw new System.NotImplementedException();
    }

    public void OnPointerDragged(MixedRealityPointerEventData eventData)
    {

        //throw new System.NotImplementedException();
    }

    public void OnPointerUp(MixedRealityPointerEventData eventData)
    {

        //throw new System.NotImplementedException();
    }
}

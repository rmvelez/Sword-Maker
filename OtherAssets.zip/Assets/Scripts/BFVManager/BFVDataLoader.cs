using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
public class BFVDataLoader : MonoBehaviour
{
    //public GameObject[] txtObs;
    public WatchVoiceManager wvm;
    public DataClass data;
    public TextMeshPro name;
    public TextMeshPro slaCount;
    public TextMeshPro failCount;
    public TextMeshPro missedCount;
    public TextMeshPro status;
    public TextMeshPro type;
    public TextMeshPro totalJobs;
    public TextMeshPro completedJobs;
    public TextMeshPro predictedEndTime;
    public TextMeshPro slaForProcessContainer;
    public TextMeshPro predictedStartTime;
    public TextMeshPro slaContainerStatus;
    bool flag = true;

    public void UpdateBFVTextValue()
    {
        name.text = data.bfvData.bfv_content_data[0].name;

        failCount.text = data.bfvData.bfv_content_data[0].failCount;

        missedCount.text = data.bfvData.bfv_content_data[0].missedCount;

        slaCount.text = data.bfvData.bfv_content_data[0].slaCount;

        status.text = data.bfvData.bfv_content_data[0].status;

        type.text = data.bfvData.bfv_content_data[0].type;

        totalJobs.text = data.bfvData.bfv_content_data[0].completionStatus.totalJobs.ToString();

        completedJobs.text = data.bfvData.bfv_content_data[0].completionStatus.completedJobs.ToString();

        predictedEndTime.text = data.bfvData.bfv_content_data[0].predictedEndTime;

        slaForProcessContainer.text = data.bfvData.bfv_content_data[0].slaForProcessContainer;

        predictedStartTime.text = data.bfvData.bfv_content_data[0].predictedStartTime;

        slaContainerStatus.text = data.bfvData.bfv_content_data[0].slaContainerStatus;

        if (flag)
        {

            wvm.BFVTalk(data.bfvData.bfv_content_data[0].speech);
            flag = false;
        }
    }
}

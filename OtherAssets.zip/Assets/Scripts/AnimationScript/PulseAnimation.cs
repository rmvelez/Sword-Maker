using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PulseAnimation : MonoBehaviour
{
    public float duration;
    // Start is called before the first frame update
    void Start()
    {
        StartAnimation();
    }

    // Update is called once per frame
    void StartAnimation()
    {
        LeanTween.scale(gameObject, new Vector3(1, 1, 1), duration).setLoopClamp();
    }
}

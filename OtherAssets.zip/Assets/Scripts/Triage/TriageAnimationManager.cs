using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
public class TriageAnimationManager : MonoBehaviour
{
    public GameObject[] canvas;
    public Transform[] positions;
    public SpriteRenderer[] spritecanvas;

    public SpriteRenderer[] infocards0;
    public SpriteRenderer[] infocards1;
    public SpriteRenderer[] infocards2;

    public TextMeshPro[] infoText0;
    public TextMeshPro[] infoText1;
    public TextMeshPro[] infoText2;

    private int index;
    private int limit;
    
    // Start is called before the first frame update
    void Start()
    {
        index = 0;
        limit = canvas.Length-1;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void NextCard()
    {
        GameObject curr = canvas[index];
        index++;
        if (index > limit)
        {
            index = 0;
        }
        print(index);
        Transform next = positions[index];

        Vector3 rotation = next.transform.rotation.ToEulerAngles();
        //Vector3 rotation = next.transform.rotation * Vector3.forward;
        LeanTween.move(curr, next.transform.position, 0.25f);
        LeanTween.rotateLocal(curr, rotation, 0.25f);
    }
    
    public void Prevcard()
    {
        GameObject curr = canvas[index];
        index--;
        if (index < 0)
        {
            index = limit;
        }
        print(index);
        Transform prev = positions[index];

        LeanTween.move(curr, prev.transform.position, 0.25f);
        Vector3 rotation = prev.transform.rotation.ToEulerAngles();
        //Vector3 rotation = prev.transform.rotation * Vector3.forward;
        LeanTween.move(curr, prev.transform.position, 0.25f);
        LeanTween.rotateLocal(curr, rotation, 0.25f);
    }
}

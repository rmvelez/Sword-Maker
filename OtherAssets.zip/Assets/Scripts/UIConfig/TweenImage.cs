using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class TweenImage : MonoBehaviour
{
    public Image image;
    public float tweenTime;
    public float fillamount;
    public DataClass dataClass;
    void Start()
    {
        dataClass = GameObject.FindGameObjectWithTag("Data").GetComponent<DataClass>();
    }

    public void TweenImageFill()
    {
        if (gameObject.name  == "completed_progress_progressPercentage")
        {
            if (dataClass.watchDashBoardData.completed_progress_progressPercentage != 0)
            {
                fillamount = ((float)dataClass.watchDashBoardData.completed_progress_progressPercentage) / 100f;
            }
        }
        else if (gameObject.name == "completed_sla_slaPercentage")
        {
            if (dataClass.watchDashBoardData.completed_sla_slaPercentage != 0)
            {
                fillamount = ((float)dataClass.watchDashBoardData.completed_sla_slaPercentage) / 100f;
            }
            
        }
        else if (gameObject.name == "completed_faults_faultsPercentage")
        {
            if (dataClass.watchDashBoardData.completed_faults_faultsPercentage != 0)
            {
                fillamount = ((float)dataClass.watchDashBoardData.completed_faults_faultsPercentage) / 100f;
            }

        }
        else
        {
            fillamount = 1f;
        }
        LeanTween.value(gameObject, fillamount, 1, tweenTime).setEasePunch().setOnUpdate((value)=>
        {
            image.fillAmount = value;
        });
    }
}

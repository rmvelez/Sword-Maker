using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
public class TextUpdater : MonoBehaviour
{
    public int targetvalue;
    //And you also need a variable that holds the increasing score number, let's call it display score
    public int displayvalue;
    //Variable for the UI Text that will show the score
    public TextMeshPro endvalue_text;
    public DataClass dataClass;
    public GameObject imageObject;
    void Start()
    {
        //Both scores start at 0
        targetvalue = 0;
        
        displayvalue = 0;

        dataClass = GameObject.FindGameObjectWithTag("Data").GetComponent<DataClass>();
        
    }

    public void SetValues(string value, bool val)
    {
        if(val)
        {
            imageObject.GetComponent<TweenImage>().TweenImageFill();
        }
        else
        {
            targetvalue = int.Parse(value);
            StartCoroutine(ScoreUpdater());
        }
    }
    private IEnumerator ScoreUpdater()
    {
        while (true)
        {
            if (displayvalue < targetvalue)
            {
                displayvalue++; //Increment the display score by 1
                endvalue_text.text = displayvalue.ToString(); //Write it to the UI
            }
            yield return new WaitForSeconds(0.02f); // I used .2 secs but you can update it as fast as you want
        }
    }
}

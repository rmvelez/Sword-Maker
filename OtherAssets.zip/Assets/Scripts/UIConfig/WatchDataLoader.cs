using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
public class WatchDataLoader : MonoBehaviour
{
    public DataClass data;
    public GameObject[] textObjs;
    public TextMeshPro completed_faults_delayed;
    public TextMeshPro timelineUpcoming_upcoming_progress_jobsYetToRun;
    public TextMeshPro completed_progress_running;
    public TextMeshPro completed_sla_missed;
    public TextMeshPro completed_progress_numByDen;
    public TextMeshPro completed_faults_abend;
    public TextMeshPro completed_progress_completed;
    public TextMeshPro timelineUpcoming_upcoming_sla_toBeMet;
    public TextMeshPro completed_faults_failed;
    public TextMeshPro completed_faults_onHold;
    public TextMeshPro completed_sla_met;
    public TextMeshPro completed_sla_numByDen;
    public TextMeshPro completed_faults_numByDen;
    public TextMeshPro timelineUpcoming_upcoming_sla_toBeMissed;
    public WatchVoiceManager wvm;
    public TextMeshPro missedCount;
    public TextMeshPro failedCount;
    public TextMeshPro toMissCount;
    bool flag = true;
    public void UpdateWatchText()
    {
        //print("Hello2");
        completed_faults_delayed.text = data.watchDashBoardData.completed_faults_delayed.ToString();
        timelineUpcoming_upcoming_progress_jobsYetToRun.text = data.watchDashBoardData.timelineUpcoming_upcoming_progress_jobsYetToRun.ToString();
        completed_progress_running.text = data.watchDashBoardData.completed_progress_running.ToString();
        completed_sla_missed.text = data.watchDashBoardData.completed_sla_missed.ToString();
        completed_progress_numByDen.text = data.watchDashBoardData.completed_progress_numByDen.ToString();
        completed_faults_abend.text = data.watchDashBoardData.completed_faults_abend.ToString();
        completed_progress_completed.text = data.watchDashBoardData.completed_progress_completed.ToString();
        timelineUpcoming_upcoming_sla_toBeMet.text = data.watchDashBoardData.timelineUpcoming_upcoming_sla_toBeMet.ToString();
        completed_faults_failed.text = data.watchDashBoardData.completed_faults_failed.ToString();
        completed_faults_onHold.text = data.watchDashBoardData.completed_faults_onHold.ToString();
        completed_sla_met.text = data.watchDashBoardData.completed_sla_met.ToString();
        completed_sla_numByDen.text = data.watchDashBoardData.completed_sla_numByDen.ToString();
        completed_faults_numByDen.text = data.watchDashBoardData.completed_faults_numByDen.ToString();
        timelineUpcoming_upcoming_sla_toBeMissed.text = data.watchDashBoardData.timelineUpcoming_upcoming_sla_toBeMissed.ToString();
        missedCount.text = data.watchDashBoardData.completed_sla_missed.ToString();
        failedCount.text = data.watchDashBoardData.completed_faults_failed.ToString();
        toMissCount.text = data.watchDashBoardData.timelineUpcoming_upcoming_sla_toBeMissed.ToString();
        if (flag)
        {
            wvm.Parsetext(data.watchDashBoardData.speech.ToString());
            flag = false;
            print("textSpoken");
        }
    }

    public void UpdateWatchTextValue()
    {
        textObjs = GameObject.FindGameObjectsWithTag("WatchText");
        //print("Hello");
        foreach(GameObject g in textObjs)
        {
            string temp = "0";
            if (g.name == "completed_faults_delayed")
            {
                temp = data.watchDashBoardData.completed_faults_delayed.ToString();
                g.GetComponent<TextMeshPro>().text = temp;
                g.GetComponent<TextUpdater>().SetValues(temp, false);
            }
            else if (g.name == "timelineUpcoming_upcoming_progress_jobsYetToRun")
            {
                temp = data.watchDashBoardData.timelineUpcoming_upcoming_progress_jobsYetToRun.ToString();
                g.GetComponent<TextMeshPro>().text = temp;
                g.GetComponent<TextUpdater>().SetValues(temp, false);
            }
            else if (g.name == "completed_progress_running")
            {
                temp = data.watchDashBoardData.completed_progress_running.ToString();
                g.GetComponent<TextMeshPro>().text = temp;
                g.GetComponent<TextUpdater>().SetValues(temp, false);
            }
            else if (g.name == "completed_sla_missed")
            {
                temp = data.watchDashBoardData.completed_sla_missed.ToString();
                g.GetComponent<TextMeshPro>().text = temp;
                g.GetComponent<TextUpdater>().SetValues(temp, false);
            }
            else if (g.name == "completed_progress_numByDen")
            {
                temp = data.watchDashBoardData.completed_progress_numByDen.ToString();
                g.GetComponent<TextMeshPro>().text = temp;
                g.GetComponent<TextUpdater>().SetValues(temp, true);
            }
            else if (g.name == "completed_faults_abend")
            {
                temp = data.watchDashBoardData.completed_faults_abend.ToString();
                g.GetComponent<TextMeshPro>().text = temp;
                g.GetComponent<TextUpdater>().SetValues(temp, false);
            }
            else if (g.name == "completed_progress_completed")
            {
                temp = data.watchDashBoardData.completed_progress_completed.ToString();
                g.GetComponent<TextMeshPro>().text = temp;
                g.GetComponent<TextUpdater>().SetValues(temp, false);
            }
            else if (g.name == "timelineUpcoming_upcoming_sla_toBeMet")
            {
                temp = data.watchDashBoardData.timelineUpcoming_upcoming_sla_toBeMet.ToString();
                g.GetComponent<TextMeshPro>().text = temp;
                g.GetComponent<TextUpdater>().SetValues(temp, false);
            }
            else if (g.name == "completed_faults_failed")
            {
                temp = data.watchDashBoardData.completed_faults_failed.ToString();
                g.GetComponent<TextMeshPro>().text = temp;
                g.GetComponent<TextUpdater>().SetValues(temp, false);
            }
            else if (g.name == "completed_faults_onHold")
            {
                temp = data.watchDashBoardData.completed_faults_onHold.ToString();
                g.GetComponent<TextMeshPro>().text = temp;
                g.GetComponent<TextUpdater>().SetValues(temp, false);
            }
            else if (g.name == "completed_sla_met")
            {
                temp = data.watchDashBoardData.completed_sla_met.ToString();
                g.GetComponent<TextMeshPro>().text = temp;
                g.GetComponent<TextUpdater>().SetValues(temp, false);
            }
            else if (g.name == "completed_faults_numByDen")
            {
                temp = data.watchDashBoardData.completed_faults_numByDen.ToString();
                g.GetComponent<TextMeshPro>().text = temp;
                g.GetComponent<TextUpdater>().SetValues(temp, true);
            }
            else if (g.name == "completed_sla_numByDen")
            {
                temp = data.watchDashBoardData.completed_sla_numByDen.ToString();
                g.GetComponent<TextMeshPro>().text = temp;
                g.GetComponent<TextUpdater>().SetValues(temp, true);
            }
            else if (g.name == "timelineUpcoming_upcoming_sla_toBeMissed")
            {
                temp = data.watchDashBoardData.timelineUpcoming_upcoming_sla_toBeMissed.ToString();
                g.GetComponent<TextMeshPro>().text = temp;
                g.GetComponent<TextUpdater>().SetValues(temp, false);
            }
        }
    }
}

using Microsoft.MixedReality.Toolkit.Input;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JobTapController : MonoBehaviour, IMixedRealityFocusHandler, IMixedRealityPointerHandler
{
    public JobViewManager jvm;
    public AppSceneManager asm;
    public void OnFocusEnter(FocusEventData eventData)
    {
        //throw new System.NotImplementedException();
    }

    public void OnFocusExit(FocusEventData eventData)
    {
        //throw new System.NotImplementedException();
    }

    public void OnPointerClicked(MixedRealityPointerEventData eventData)
    {
        if(gameObject.name == "FailedTrigger")
        {
            jvm.SpawnFailedObjects();
        }
        else if (gameObject.name == "MissedTrigger")
        {
            jvm.SpawnMissedObjects();
        }
        else if (gameObject.name == "PredictedToMissTrigger")
        {
            jvm.SpawnToMissObjects();
        }
        else if(gameObject.name == "OrderManagement")
        {
            //asm.ActivateBFV();
            jvm.ResetObjects();
        }
    }

    public void OnPointerDown(MixedRealityPointerEventData eventData)
    {
        //throw new System.NotImplementedException();
    }

    public void OnPointerDragged(MixedRealityPointerEventData eventData)
    {
        //throw new System.NotImplementedException();
    }

    public void OnPointerUp(MixedRealityPointerEventData eventData)
    {
        //throw new System.NotImplementedException();
    }
}

using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class JobViewManager : MonoBehaviour
{
    private DataClass dataClass;

    public GameObject[] failedObjPrefabs;
    public GameObject[] missedObjPrefabs;
    public GameObject[] toMissObjPrefabs;

    public GameObject failedParent;
    public GameObject failedParentSphere;

    public GameObject missedParent;
    public GameObject missedParentSphere;

    public GameObject toMissParent;
    public GameObject toMissParentSphere;

    public GameObject failedTrigger;
    public GameObject missedTrigger;
    public GameObject tomissTrigger;

    public TextMeshPro failedCount;
    public TextMeshPro missedCount;
    public TextMeshPro tomissCount;
    public ShowObjectOptions ObjOp;

    private void Start()
    {
        dataClass = GameObject.FindGameObjectWithTag("Data").GetComponent<DataClass>();
    }
    public void SpawnObjects(string status, int count)
    {
        int limit = 0;
        if(status == "failed")
        {
            if (count < 8)
            {
                limit = count;
            }
            else
            {
                limit = 8;
            }
            for (int i = 0; i < limit; i++)
            {
                failedObjPrefabs[i].SetActive(true);
                failedObjPrefabs[i].name = dataClass.ffData.faults_failed[i].name;
                failedObjPrefabs[i].GetComponent<FaultsDataLoader>().UpdateFaultData(dataClass.ffData.faults_failed[i]);
            }

        }
        else if(status == "missed")
        {
            if (count < 8)
            {
                limit = count;
            }
            else
            {
                limit = 8;
            }
            for (int i = 0; i < limit; i++)
            {
                missedObjPrefabs[i].SetActive(true);
                missedObjPrefabs[i].GetComponent<MissedDataLoader>().UpdateMissedData(dataClass.missedData.missed[i]);
            }
        }
        else if(status == "tomiss")
        {
            if (count < 8)
            {
                limit = count;
            }
            else
            {
                limit = 8;
            }
            for (int i = 0; i < limit; i++)
            {
                toMissObjPrefabs[i].SetActive(true);
                toMissObjPrefabs[i].GetComponent<ToMissDataLoader>().UpdateToMissData(dataClass.toMissData.tobemissed[i]);
            }
        }
        
    }

    public void SpawnFailedObjects()
    {
        DeactivateObjects();
        failedParentSphere.SetActive(true);
        ActivateTriggers(1);
        SpawnObjects("failed", dataClass.watchDashBoardData.completed_faults_failed);
        UpdateLabel();
    }

    public void SpawnMissedObjects()
    {
        
        DeactivateObjects();
        missedParentSphere.SetActive(true);
        ActivateTriggers(2);
        SpawnObjects("missed", dataClass.watchDashBoardData.completed_sla_missed);
        UpdateLabel();
    }

    public void SpawnToMissObjects()
    {
        DeactivateObjects();
        toMissParentSphere.SetActive(true);
        ActivateTriggers(3);
        SpawnObjects("tomiss", dataClass.watchDashBoardData.timelineUpcoming_upcoming_sla_toBeMissed);
        UpdateLabel();
    }
    public void ActivateTriggers(int index)
    {
        DeactivateTriggers();
        if (index == 1)
        {
            missedTrigger.SetActive(true);
            tomissTrigger.SetActive(true);
        }
        else if (index == 2)
        {
            failedTrigger.SetActive(true);
            tomissTrigger.SetActive(true);
        }
        else if (index == 3)
        {
            failedTrigger.SetActive(true);
            missedTrigger.SetActive(true);
        }
        else if(index == 0)
        {
            failedTrigger.SetActive(true);
            missedTrigger.SetActive(true);
            tomissTrigger.SetActive(true);
        }
    }
    

    public void DeactivateObjects()
    {
        DeactivateJobParent();
        foreach (GameObject g in failedObjPrefabs)
        {
            g.SetActive(false);
        }

        foreach (GameObject g in missedObjPrefabs)
        {
            g.SetActive(false);
        }

        foreach (GameObject g in toMissObjPrefabs)
        {
            g.SetActive(false);
        }
        DeactivateTriggers();
        ObjOp.ResetOptions();
    }

    public void DeactivateJobParent()
    {
        failedParentSphere.SetActive(false);
        missedParentSphere.SetActive(false);
        toMissParentSphere.SetActive(false);
        //failedJobsActive = false;
    }

    public void DeactivateTriggers()
    {
        failedTrigger.SetActive(false);
        missedTrigger.SetActive(false);
        tomissTrigger.SetActive(false);
    }
    public void UpdateLabel()
    {
        failedCount.text = dataClass.ffData.numberOfElements.ToString();
        missedCount.text = dataClass.missedData.numberOfElements.ToString();
        tomissCount.text = dataClass.toMissData.numberOfElements.ToString();
    }
    public void ResetObjects()
    {
        DeactivateObjects();
        ActivateTriggers(0);
    }
}

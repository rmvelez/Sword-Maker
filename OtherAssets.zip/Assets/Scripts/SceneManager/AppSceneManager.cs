using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AppSceneManager : MonoBehaviour
{
    public GameObject bfvObject;
    public GameObject jobViewObject;
    public GameObject jobsObject;
    public JobViewManager jvm;

    public GameObject impactViewObject;

    public GameObject impactChartCurrent;
    public GameObject impactObjectCurrent;

    public GameObject impactChart30;
    public GameObject impactObject30;

    public GameObject impactChart60;
    public GameObject impactObject60;

    public GameObject impactChart90;
    public GameObject impactObject90;
    public GameObject NoDataObject;

    //public MeshRenderer jobOne;
    //public MeshRenderer jobTwo;
    public GameObject jobOne;
    public GameObject jobTwo;

    // reference to orbs that can be grabbed on Impact SLA Screen
    
    public GameObject currentObj;
    public GameObject thirtyOneObj;
    public GameObject thirtyTwoObj;
    
    public GameObject sixtyOneObj;
    public GameObject sixtyTwoObj;
    public GameObject ninetyOneObj;
    public GameObject ninetyTwoObj;
    public GameObject ninetyThreeObj;

    // reference to orbs that are used to reference the location of the dock where the SLA Spheres can be placed
    
    public GameObject currentRef;
    public GameObject thirtyOneRef;
    public GameObject thirtyTwoRef;
    
    public GameObject sixtyOneRef;
    public GameObject sixtyTwoRef;
    public GameObject ninetyOneRef;
    public GameObject ninetyTwoRef;
    public GameObject ninetyThreeRef;

    public void DeactivateAll()
    {
        bfvObject.SetActive(false);
        jobViewObject.SetActive(false);
        jobsObject.SetActive(false);

        impactChartCurrent.SetActive(false);
        impactObjectCurrent.SetActive(false);

        impactChart30.SetActive(false);
        impactObject30.SetActive(false);

        impactChart60.SetActive(false);
        impactObject60.SetActive(false);

        impactChart90.SetActive(false);
        impactObject90.SetActive(false);
        
        impactViewObject.SetActive(false);
        NoDataObject.SetActive(false);
    }

    public void ActivateBFV()
    {
        DeactivateAll();
        DeactivateImpactSLAInteractables();
        bfvObject.SetActive(true);
        bfvObject.GetComponent<BFVDataLoader>().UpdateBFVTextValue();
    }

    public void ActivateJV()
    {
        DeactivateAll();
        DeactivateImpactSLAInteractables();
        jobViewObject.SetActive(true);
        jobViewObject.GetComponent<WatchDataLoader>().UpdateWatchText();
        jobsObject.SetActive(false);
    }

    public void ActivateJV(string text)
    {
        DeactivateAll();
        bfvObject.SetActive(true);
        jobsObject.SetActive(true);
        if (text == "Failed")
        {
            jvm.SpawnFailedObjects();
            //jobOne.enabled = true;
            //jobTwo.enabled = true;
            jobOne.SetActive(false);
            jobTwo.SetActive(false);
        }
        else if (text == "Missed")
        {
            jvm.SpawnMissedObjects();
        }
        else if (text == "ToMiss")
        {
            jvm.SpawnToMissObjects();
        }
    }

    public void ActivateJobsParent()
    {
        jobsObject.SetActive(true);
    }

    private void DeactivateImpactSLAInteractables()
    {
        currentObj.SetActive(false);
        currentRef.SetActive(false);

        thirtyOneObj.SetActive(false);
        thirtyOneRef.SetActive(false);
        thirtyTwoObj.SetActive(false);
        thirtyTwoRef.SetActive(false);
        
        sixtyOneObj.SetActive(false);
        sixtyOneRef.SetActive(false);
        sixtyTwoObj.SetActive(false);
        sixtyTwoRef.SetActive(false);

        ninetyOneObj.SetActive(false);
        ninetyOneRef.SetActive(false);
        ninetyTwoObj.SetActive(false);
        ninetyTwoRef.SetActive(false);
        ninetyThreeObj.SetActive(false);
        ninetyThreeRef.SetActive(false);
    }
}

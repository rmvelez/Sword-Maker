/*
{
  "completed_faults_delayed": 1,
  "timelineUpcoming_upcoming_progress_jobsYetToRun": 103,
  "completed_progress_running": 1,
  "completed_sla_missed": 1,
  "completed_progress_numByDen": "88 / 191",
  "completed_faults_abend": 0,
  "completed_progress_completed": 84,
  "timelineUpcoming_timeline_desiredEndTime": 0,
  "timelineUpcoming_timeline_predictedEndTime": 1622063912000,
  "completed_faults_impactedSla": 0,
  "completed_progress_progressPercentage": 46,
  "timelineUpcoming_timeline_lastFeedUpdated": 1622024312000,
  "timelineUpcoming_upcoming_sla_toBeMet": 6,
  "completed_sla_slaPercentage": 18,
  "timelineUpcoming_timeline_startTime": 1621987200000,
  "timelineUpcoming_timeline_currentTime": 1622024312000,
  "completed_faults_failed": 2,
  "completed_faults_onHold": 1,
  "completed_sla_met": 1,
  "completed_sla_numByDen": "2 / 11",
  "speech": "There are 2 Failures,1 Missed S L A and 3 Predicted to miss.",
  "completed_faults_numByDen": "4 / 88",
  "timelineUpcoming_upcoming_faults_impactedSla": 0,
  "timelineUpcoming_upcoming_sla_toBeMissed": 3,
  "completed_faults_faultsPercentage": 5,
  "completed_progress_failed": 3
} 
*/

[System.Serializable]
public class WatchDashBoardData
{
    public int completed_faults_delayed;
    public int timelineUpcoming_upcoming_progress_jobsYetToRun;
    public int completed_progress_running;
    public int completed_sla_missed;
    public string completed_progress_numByDen;
    public int completed_faults_abend;
    public int completed_progress_completed;
    public ulong timelineUpcoming_timeline_desiredEndTime;
    public ulong timelineUpcoming_timeline_predictedEndTime;
    public int completed_faults_impactedSla;
    public int completed_progress_progressPercentage;
    public ulong timelineUpcoming_timeline_lastFeedUpdated;
    public int timelineUpcoming_upcoming_sla_toBeMet;
    public int completed_sla_slaPercentage;
    public ulong timelineUpcoming_timeline_startTime;
    public ulong timelineUpcoming_timeline_currentTime;
    public int completed_faults_failed;
    public int completed_faults_onHold;
    public int completed_sla_met;
    public string completed_sla_numByDen;
    public string speech;
    public string completed_faults_numByDen;
    public int timelineUpcoming_upcoming_faults_impactedSla;
    public int timelineUpcoming_upcoming_sla_toBeMissed;
    public int completed_faults_faultsPercentage;
    public int completed_progress_failed;
}

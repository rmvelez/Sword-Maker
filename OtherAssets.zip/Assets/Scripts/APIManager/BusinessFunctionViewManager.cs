using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class BusinessFunctionViewManager : MonoBehaviour
{
    public BFVData bfvData;
    public BFVDataLoader bfvDataLoader;
    public DataClass dataClass;
    public string watchId;
    public FaultsFailedManager faultsFailedManager;
    public MissedManager missedManager;
    public ToMissManager toMissManager;
    // Start is called before the first frame update
    void Start()
    {
        ProcessAPIRequest(watchId, dataClass.configData.bfvRequestUrl);
    }

    public void ProcessAPIRequest(string watchId, string url)
    {
        //dataLoader.UpdateWatchTextValue();
        StartCoroutine(RequestData(watchId, url));
    }

    public IEnumerator RequestData(string id, string apiRequestUrl)
    {
        UnityWebRequest unityWebRequest = new UnityWebRequest(apiRequestUrl, "Get");
        unityWebRequest.downloadHandler = new DownloadHandlerBuffer();

        yield return unityWebRequest.SendWebRequest();

        if (!unityWebRequest.isNetworkError)
        {
            ProcessResponseData(unityWebRequest.downloadHandler.text);
        }
        else
        {
            Debug.Log("Error While Sending: " + unityWebRequest.error);
        }

    }

    private void ProcessResponseData(string data)
    {
        bfvData = JsonUtility.FromJson<BFVData>(data);
        faultsFailedManager.ProcessAPIRequest(bfvData.bfv_content_data[0].faults_failed_url);
        missedManager.ProcessAPIRequest(bfvData.bfv_content_data[0].missed_url);
        toMissManager.ProcessAPIRequest(bfvData.bfv_content_data[0].predicted_to_miss_url);
        dataClass.setBFVData(bfvData);
        bfvDataLoader.UpdateBFVTextValue();
    }

}


[System.Serializable]
public class ConfigData
{
    public string hostUrl;
    public string watchDashRequestUrl;
    public string bfvRequestUrl;
    public string triageRequestUrl;
}

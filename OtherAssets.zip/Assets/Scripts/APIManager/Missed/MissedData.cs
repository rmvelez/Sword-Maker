/*
 {
  "numberOfElements": 1,
  "size": 20,
  "totalPages": 1,
  "totalElements": 1,
  "missed": [
    {
      "paramapi": "/solutions/process/watch/getRealTimeEvidenceForSLA?workItemId=2021-07-01-51&nodeId=36cf90a7bae848cab1170da61e000cf8&slaType=EndSLAViolation&appliedFixId=&fixWorkitemId=null&date=20210701&buId=b3d7420376f345ccb41fe43b777eda17&eventName=EndSLAViolation&nodeType=AutosysJob",
      "type": "Autosys Job",
      "name": "settle_bulk_accounts_cdp_g1_bat",
      "sla_type": "Endtime SLA Violation",
      "sla_value": "Jul 01 2021 | 02:30:00 PM +0530",
      "predicted_value": "Jul 01 2021 | 02:35:00 PM +0530",
      "sla_status": "MISSED",
      "likely_cause": "No Cause Found"
    }
  ]
}
*/

[System.Serializable]
public class MissedData
{
    public int numberOfElements;
    public int size;
    public int totalPages;
    public int totalElements;
    public Missed[] missed;
}

[System.Serializable]
public class Missed
{
    public string paramapi;
    public string type;
    public string name;
    public string sla_type;
    public string sla_value;
    public string predicted_value;
    public string sla_status;
    public string likely_cause;
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class MissedDataLoader : MonoBehaviour
{
    public TextMeshPro type;
    public TextMeshPro name;
    public TextMeshPro sla_type;
    public TextMeshPro sla_value;
    public TextMeshPro predicted_value;
    public TextMeshPro sla_status;
    public TextMeshPro likely_cause;

    public void UpdateMissedData(Missed missed)
    {
        type.text = missed.type;
        name.text = missed.name;
        sla_type.text = missed.sla_type;
        sla_value.text = missed.sla_value;
        predicted_value.text = missed.predicted_value;
        sla_status.text = missed.sla_status;
        likely_cause.text = missed.likely_cause;
    }
}

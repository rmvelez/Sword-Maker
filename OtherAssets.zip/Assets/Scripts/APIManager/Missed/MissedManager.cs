using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class MissedManager : MonoBehaviour
{
    public MissedData missedData;
    public DataClass dataClass;
    public void ProcessAPIRequest(string url)
    {
        url = dataClass.configData.hostUrl + url;
        StartCoroutine(RequestData(url));
    }

    public IEnumerator RequestData(string apiRequestUrl)
    {
        UnityWebRequest unityWebRequest = new UnityWebRequest(apiRequestUrl, "Get");
        unityWebRequest.downloadHandler = new DownloadHandlerBuffer();

        yield return unityWebRequest.SendWebRequest();

        if (!unityWebRequest.isNetworkError)
        {
            ProcessResponseData(unityWebRequest.downloadHandler.text);
        }
        else
        {
            Debug.Log("Error While Sending: " + unityWebRequest.error);
        }

    }

    private void ProcessResponseData(string data)
    {
        missedData = JsonUtility.FromJson<MissedData>(data);
        dataClass.setMissedData(missedData);
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DataClass : MonoBehaviour
{
    public ConfigData configData;
    public WatchDashBoardData watchDashBoardData;
    public BFVData bfvData;
    public FaultsFailedData ffData;
    public MissedData missedData;
    public ToMissData toMissData;
    public TriageData triageData;
    public ImpactSLAData impactSLAData;
    public ImpactCurrentGraphData icd;
    public Impact30GraphData i3d;
    public Impact60GraphData i6d;
    public Impact90GraphData i9d;

    public ThresholdData thresholdData;
    public VitalsData vitalsData;
    public DependenciesData dependenciesData;
    
    public void setWatchDashBoardData(WatchDashBoardData data)
    {
        watchDashBoardData = data;
        
    }

    public void setConfigData(ConfigData data)
    {
        configData = data;
    }

    public void setBFVData(BFVData data)
    {
        bfvData = data;
    }

    public void setFFData(FaultsFailedData data)
    {
        ffData = data;
    }

    public void setMissedData(MissedData data)
    {
        missedData = data;
    }

    public void setToMissData(ToMissData data)
    {
        toMissData = data;
    }

    public void setTriageData(TriageData data)
    {
        triageData = data;
    }

    public void setImpactSLAData(ImpactSLAData data)
    {
        impactSLAData = data;
    }

    public void setImpactCurrentGraphData(ImpactCurrentGraphData data)
    {
        icd = data;
    }

    public void setImpact30GraphData(Impact30GraphData data)
    {
        i3d = data;
    }

    public void setImpact60GraphData(Impact60GraphData data)
    {
        i6d = data;
    }

    public void setImpact90GraphData(Impact90GraphData data)
    {
        i9d = data;
    }

    public void setThresholdData(ThresholdData data)
    {
        thresholdData = data;
    }
    
    public void setVitalsData(VitalsData data)
    {
        vitalsData = data;
    }
    
    public void setDependenciesData(DependenciesData data)
    {
        dependenciesData = data;
    }
}

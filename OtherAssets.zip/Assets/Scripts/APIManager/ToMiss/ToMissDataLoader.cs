using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
public class ToMissDataLoader : MonoBehaviour
{
    public TextMeshPro type;
    public TextMeshPro name;
    public TextMeshPro sla_type;
    public TextMeshPro sla_value;
    public TextMeshPro predicted_value;
    public TextMeshPro sla_status;
    public TextMeshPro likely_cause;
    public TextMeshPro available_fix;

    public void UpdateToMissData(ToBeMissed tobemissed)
    {
        type.text = tobemissed.type;
        name.text = tobemissed.name;
        sla_type.text = tobemissed.sla_type;
        sla_value.text = tobemissed.sla_value;
        predicted_value.text = tobemissed.predicted_value;
        sla_status.text = tobemissed.sla_status;
        likely_cause.text = tobemissed.likely_cause;
        available_fix.text = tobemissed.available_fix;
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class ToMissManager : MonoBehaviour
{
    public ToMissData toMissData;
    public DataClass dataClass;
    public void ProcessAPIRequest(string url)
    {
        url = dataClass.configData.hostUrl + url;
        StartCoroutine(RequestData(url));
    }

    public IEnumerator RequestData(string apiRequestUrl)
    {
        UnityWebRequest unityWebRequest = new UnityWebRequest(apiRequestUrl, "Get");
        unityWebRequest.downloadHandler = new DownloadHandlerBuffer();

        yield return unityWebRequest.SendWebRequest();

        if (!unityWebRequest.isNetworkError)
        {
            ProcessResponseData(unityWebRequest.downloadHandler.text);
        }
        else
        {
            Debug.Log("Error While Sending: " + unityWebRequest.error);
        }

    }

    private void ProcessResponseData(string data)
    {
        toMissData = JsonUtility.FromJson<ToMissData>(data);
        dataClass.setToMissData(toMissData);
    }
}

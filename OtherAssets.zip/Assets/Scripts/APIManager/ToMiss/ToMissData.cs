/*
 {
  "numberOfElements": 3,
  "size": 20,
  "totalPages": 1,
  "totalElements": 3,
  "tobemissed": [
    {
      "paramapi": "/solutions/process/watch/getRealTimeEvidenceForSLA?workItemId=2021-07-01-51&nodeId=142fd0e59de14b0fa1faaa51fdd224d1&slaType=EndSLAViolation&appliedFixId=&fixWorkitemId=null&date=20210701&buId=b3d7420376f345ccb41fe43b777eda17&eventName=EndSLAViolation&nodeType=AutosysJob&lastState=TOBEMISSED",
      "type": "Autosys Job",
      "name": "eod_settlements_debit_cdp_f6_bat",
      "sla_type": "Endtime SLA Violation",
      "sla_value": "Jul 01 2021 | 07:20:00 PM +0530",
      "predicted_value": "Jul 01 2021 | 07:48:32 PM +0530",
      "sla_status": "PREDICTED TO MISS",
      "likely_cause": "No Cause Found",
      "available_fix": "4"
    },
    {
      "paramapi": "/solutions/process/watch/getRealTimeEvidenceForSLA?workItemId=2021-07-01-51&nodeId=1912dfc5912d404c9614c44bfee08f90&slaType=EndSLAViolation&appliedFixId=&fixWorkitemId=null&date=20210701&buId=b3d7420376f345ccb41fe43b777eda17&eventName=EndSLAViolation&nodeType=AutosysJob&lastState=TOBEMISSED",
      "type": "Autosys Job",
      "name": "reconcile_tailend_credits_cdp_g6_bat",
      "sla_type": "Endtime SLA Violation",
      "sla_value": "Jul 01 2021 | 07:40:00 PM +0530",
      "predicted_value": "Jul 01 2021 | 07:48:32 PM +0530",
      "sla_status": "PREDICTED TO MISS",
      "likely_cause": "No Cause Found",
      "available_fix": "4"
    },
    {
      "paramapi": "/solutions/process/watch/getRealTimeEvidenceForSLA?workItemId=2021-07-01-51&nodeId=9535e3f2776245e39b9922d62706fb04&slaType=EndSLAViolation&appliedFixId=&fixWorkitemId=null&date=20210701&buId=b3d7420376f345ccb41fe43b777eda17&eventName=EndSLAViolation&nodeType=AutosysJob&lastState=TOBEMISSED",
      "type": "Autosys Job",
      "name": "ign_publish_pricing_files_bat",
      "sla_type": "Endtime SLA Violation",
      "sla_value": "Jul 02 2021 | 01:57:00 AM +0530",
      "predicted_value": "Jul 02 2021 | 02:27:12 AM +0530",
      "sla_status": "PREDICTED TO MISS",
      "likely_cause": "ign_rms_ora_prq_rpm_a53_bat",
      "available_fix": "11"
    }
  ]
}
*/

[System.Serializable]
public class ToMissData
{
    public int numberOfElements;
    public int size;
    public int totalPages;
    public int totalElements;
    public ToBeMissed[] tobemissed;
}

[System.Serializable]
public class ToBeMissed
{
    public string paramapi;
    public string type;
    public string name;
    public string sla_type;
    public string sla_value;
    public string predicted_value;
    public string sla_status;
    public string likely_cause;
    public string available_fix;
}


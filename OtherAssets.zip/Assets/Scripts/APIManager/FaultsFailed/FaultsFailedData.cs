/*
 {
  "numberOfElements": 2,
  "size": 20,
  "totalPages": 1,
  "totalElements": 2,
  "faults_failed": [
    {
      "sla_obj_url": "/solutions/process/watch/getRealTimeEvidenceForFaults?workItemId=2021-10-29-48&nodeId=192bfe3e914f4f16a4b62d1548f043e4&faultType=FAILURE&buId=b3d7420376f345ccb41fe43b777eda17&date=20211029&eventName=FAILURE&nodeType=AutosysJob",
      "type": "Autosys Job",
      "name": "ign_exec_batch_d1_bat",
      "status": "FAILURE",
      "fault_time": "Oct 29 2021 | 01:45:00 PM +0530",
      "predicted_end_time": "Oct 29 2021 | 03:48:33 PM +0530",
      "sla_at_risk_now": "0",
      "sla_at_risk_in_future": "0",
      "sla_downstream_count": "0",
      "job_run": "1"
    },
    {
      "sla_obj_url": "/solutions/process/watch/getRealTimeEvidenceForFaults?workItemId=2021-10-29-48&nodeId=da0c754085884bba8a46e59110a5e4c0&faultType=FAILURE&buId=b3d7420376f345ccb41fe43b777eda17&date=20211029&eventName=FAILURE&nodeType=UC4Job",
      "type": "UC4 Job",
      "name": "create_card_query_file_cdp_f2_bat",
      "status": "FAILURE",
      "fault_time": "Oct 29 2021 | 03:48:00 PM +0530",
      "predicted_end_time": "Oct 29 2021 | 03:48:33 PM +0530",
      "desired_end_time": "Oct 29 2021 | 04:20:00 PM +0530",
      "sla_at_risk_now": "0",
      "sla_at_risk_in_future": "2",
      "sla_downstream_count": "3",
      "job_run": "1"
    }
  ]
}
*/

[System.Serializable]
public class FaultsFailedData
{
    public int numberOfElements;
    public int size;
    public int totalPages;
    public int totalElements;
    public Faults_Failed[] faults_failed;
}

[System.Serializable]
public class Faults_Failed
{
    public string sla_obj_url;
    public string type;
    public string name;
    public string status;
    public string fault_time;
    public string predicted_end_time;
    public string desired_end_time;
    public string sla_at_risk_now;
    public string sla_at_risk_in_future;
    public string sla_downstream_count;
    public string job_run;
}

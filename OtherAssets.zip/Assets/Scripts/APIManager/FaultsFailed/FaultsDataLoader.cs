using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class FaultsDataLoader : MonoBehaviour
{
    public TextMeshPro type;
    public TextMeshPro name;
    public TextMeshPro status;
    public TextMeshPro fault_time;
    public TextMeshPro predicted_end_time;
    public TextMeshPro desired_end_time;
    public TextMeshPro sla_at_risk_now;
    public TextMeshPro sla_at_risk_in_future;
    public TextMeshPro sla_downstream_count;
    public TextMeshPro job_run;

    public void UpdateFaultData(Faults_Failed fault_failed)
    {
        type.text = fault_failed.type;
        name.text = fault_failed.name;
        status.text = fault_failed.status;
        fault_time.text = fault_failed.fault_time;
        predicted_end_time.text = fault_failed.predicted_end_time;
        desired_end_time.text = fault_failed.desired_end_time;
        sla_at_risk_now.text = fault_failed.sla_at_risk_now;
        sla_at_risk_in_future.text = fault_failed.sla_at_risk_in_future;
        sla_downstream_count.text = fault_failed.sla_downstream_count;
        job_run.text = fault_failed.job_run;
    }
}

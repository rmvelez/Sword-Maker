/*
{
  "triage_faults": [
    {
      "triage_entity_name": "create_card_query_file_cdp_f2_bat",
      "details": [
        {
          "fault_name": "Service Down",
          "entity_type": "Service",
          "expected_value": "Running",
          "reported_value": "Stopped",
          "fix_description": "StartService",
          "speech": "Fault name is Service Down. Entity Type is Service. Fix is 'StartService'"
        },
        {
          "fault_name": "Failure Event",
          "entity_type": "UC4 Job",
          "expected_value": "SUCCESS,RUNNING",
          "reported_value": "FAILED",
          "fix_description": "Fix Job Failure",
          "speech": "Fault name is Failure Event. Entity Type is UC4 Job. Fix is 'Fix Job Failure'"
        }
      ],
      "speech_summary": "There are 2 faults"
    },
    {
      "triage_entity_name": "ign_exec_batch_d1_bat",
      "details": [
        {
          "fault_name": "Boot FileSystem High Utilization",
          "entity_type": "Linux",
          "expected_value": "NA",
          "reported_value": "14",
          "fix_description": "Uninstall Kernel",
          "speech": "Fault name is Boot FileSystem High Utilization. Entity Type is Linux. Fix is 'Uninstall Kernel'"
        },
        {
          "fault_name": "Failure Event",
          "entity_type": "Autosys Job",
          "expected_value": "SUCCESS,RUNNING",
          "reported_value": "FAILED",
          "fix_description": "Lookup and Fix",
          "speech": "Fault name is Failure Event. Entity Type is Autosys Job. Fix is 'Lookup and Fix'"
        }
      ],
      "speech_summary": "There are 2 faults"
    }
  ]
}
*/


[System.Serializable]
public class TriageData
{
    public Triage_Faults[] triage_faults;
}

[System.Serializable]
public class Triage_Faults
{
    public string triage_entity_name;
    public Details[] details;
    public string speech_summary;
}

[System.Serializable]
public class Details
{
    public string fault_name;
    public string entity_type;
    public string expected_value;
    public string reported_value;
    public string fix_description;
    public string speech;
}

using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class TriageDataLoader : MonoBehaviour
{
    public GameObject TitleCard;
    public GameObject InfoCard;
    public GameObject DescriptionCard;
    public GameObject BackButton;
    public GameObject FailedOptions;
    public GameObject NextButton;
    public GameObject PrevButton;
    public DataClass dataClass;
    public TextMeshPro totalFaults;
    public TextMeshPro faultName;
    public TextMeshPro entityType;
    public TextMeshPro expectedValue;
    public TextMeshPro reportedValue;
    public TextMeshPro fixDescription;

    public WatchVoiceManager wvm;
    public int selectedIndex;
    public string selectedObj;
    public int count = 0;

    public TriageData td;
    public void ShowTriage()
    {
        TitleCard.SetActive(true);
        InfoCard.SetActive(true);
        DescriptionCard.SetActive(true);
        BackButton.SetActive(true);
        FailedOptions.SetActive(false);
        PrevButton.SetActive(true);
        NextButton.SetActive(true);
        wvm.Parsetext(dataClass.triageData.triage_faults[selectedIndex].speech_summary);
    }
    public void HideTriage()
    {
        TitleCard.SetActive(false);
        InfoCard.SetActive(false);
        DescriptionCard.SetActive(false);
        BackButton.SetActive(false);
        FailedOptions.SetActive(true);
        PrevButton.SetActive(false);
        NextButton.SetActive(false);
    }


    public void UpdateText(string objName)
    {
        selectedObj = objName;
        //print("Updater Called" + selectedObj);
        td = dataClass.triageData;
        for (int i = 0; i < td.triage_faults.Length; i++)
        {
            if (selectedObj == td.triage_faults[i].triage_entity_name)
            {
                selectedIndex = i;
            }
        }

        totalFaults.text = td.triage_faults[selectedIndex].details.Length.ToString();
        faultName.text = td.triage_faults[selectedIndex].details[0].fault_name;
        entityType.text = td.triage_faults[selectedIndex].details[0].entity_type;
        expectedValue.text = td.triage_faults[selectedIndex].details[0].expected_value;
        reportedValue.text = td.triage_faults[selectedIndex].details[0].reported_value;
        fixDescription.text = td.triage_faults[selectedIndex].details[0].fix_description;
    }

    public void NextFault()
    {
        count++;
        if (count < td.triage_faults[selectedIndex].details.Length)
        {
            faultName.text = td.triage_faults[selectedIndex].details[count].fault_name;
            entityType.text = td.triage_faults[selectedIndex].details[count].entity_type;
            expectedValue.text = td.triage_faults[selectedIndex].details[count].expected_value;
            reportedValue.text = td.triage_faults[selectedIndex].details[count].reported_value;
            fixDescription.text = td.triage_faults[selectedIndex].details[count].fix_description;
            wvm.Parsetext(dataClass.triageData.triage_faults[selectedIndex].details[count].speech);
        }
        else
        {
            count = td.triage_faults[selectedIndex].details.Length - 1;
        }
    }

    public void PrevFault()
    {
        count--;
        if (count >= 0)
        {
            faultName.text = td.triage_faults[selectedIndex].details[count].fault_name;
            entityType.text = td.triage_faults[selectedIndex].details[count].entity_type;
            expectedValue.text = td.triage_faults[selectedIndex].details[count].expected_value;
            reportedValue.text = td.triage_faults[selectedIndex].details[count].reported_value;
            fixDescription.text = td.triage_faults[selectedIndex].details[count].fix_description;
            wvm.Parsetext(dataClass.triageData.triage_faults[selectedIndex].details[count].speech);
        }
        else
        {
            count = 0;
        }
    }

}

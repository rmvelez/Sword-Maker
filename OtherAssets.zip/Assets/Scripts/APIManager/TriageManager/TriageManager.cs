using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class TriageManager : MonoBehaviour
{
    public DataClass dataClass;
    public TriageData triageData;
    // Start is called before the first frame update
    void Start()
    {
        ProcessAPIRequest(dataClass.configData.triageRequestUrl);
        //print("method called");
    }

    public void ProcessAPIRequest(string url)
    {
        StartCoroutine(RequestData(url));
    }

    public IEnumerator RequestData(string url)
    {
        UnityWebRequest unityWebRequest = new UnityWebRequest(url, "Get");
        unityWebRequest.downloadHandler = new DownloadHandlerBuffer();

        yield return unityWebRequest.SendWebRequest();

        if (!unityWebRequest.isNetworkError)
        {
            ProcessResponseData(unityWebRequest.downloadHandler.text);
        }
        else
        {
            Debug.Log("Error While Sending: " + unityWebRequest.error);
        }
    }

    private void ProcessResponseData(string data)
    {
        triageData = JsonUtility.FromJson<TriageData>(data);
        dataClass.setTriageData(triageData);
        //print("DataLoaded");
    }
}

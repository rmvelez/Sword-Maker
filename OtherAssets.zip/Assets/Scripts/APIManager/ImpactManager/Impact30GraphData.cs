[System.Serializable]
public class Impact30GraphData
{
    public double lastfeedtimestamp;
    public GraphData[] graphdata;
    public DependencyData[] dependencyData;
}

[System.Serializable]
public class Impact60GraphData
{
    public double lastfeedtimestamp;
    public GraphData[] graphdata;
    public DependencyData[] dependencyData;
}

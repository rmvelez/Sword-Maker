[System.Serializable]
public class Impact90GraphData
{
    public double lastfeedtimestamp;
    public GraphData[] graphdata;
    public DependencyData[] dependencyData;
}

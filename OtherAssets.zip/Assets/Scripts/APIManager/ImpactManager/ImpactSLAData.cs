/*
 {
  "slacode30min": [
    {
      "codename30min": "Impacted SLA",
      "codestatus30min": "impacted",
      "colorindex30min": "4"
    },
    {
      "codename30min": "Downstream Jobs",
      "codestatus30min": "none",
      "colorindex30min": "0"
    },
    {
      "codename30min": "Failed Job",
      "codestatus30min": "fault",
      "colorindex30min": "3"
    },
    {
      "codename30min": "Desired State",
      "codestatus30min": "desiredState",
      "colorindex30min": "6"
    }
  ],
  "sla30min": [
    {
      "type": "Autosys Job",
      "typehidden": "false",
      "name": "eod_settlements_debit_cdp_f6_bat",
      "namehidden": "false",
      "slatype": "Endtime SLA Violation",
      "slatypehidden": "false",
      "slavalue": "May 21 2021 | 07:20:00 PM +0530",
      "slavaluehidden": "false",
      "observedvalue": "May 21 2021 | 08:18:32 PM +0530",
      "observedvaluehidden": "false"
    },
    {
      "type": "Autosys Job",
      "typehidden": "false",
      "name": "process_settlements_prenote_cdp_f9_bat",
      "namehidden": "false",
      "slatype": "Endtime SLA Violation",
      "slatypehidden": "false",
      "slavalue": "May 21 2021 | 08:30:00 PM +0530",
      "slavaluehidden": "false",
      "observedvalue": "May 21 2021 | 08:48:32 PM +0530",
      "observedvaluehidden": "false"
    }
  ],
  "slaDetails": {
    "status": "FAILURE",
    "statushidden": "false",
    "faulttime": "May 21 2021 | 03:48:00 PM +0530",
    "faulttimehidden": "false",
    "desiredendtime": "May 21 2021 | 04:20:00 PM +0530",
    "desiredendtimehidden": "false"
  },
  "slacodecurrent": [
    {
      "codenamecurrent": "Impacted SLA",
      "codestatuscurrent": "impacted",
      "colorindexcurrent": "4"
    },
    {
      "codenamecurrent": "Downstream Jobs",
      "codestatuscurrent": "none",
      "colorindexcurrent": "0"
    },
    {
      "codenamecurrent": "Failed Job",
      "codestatuscurrent": "fault",
      "colorindexcurrent": "3"
    },
    {
      "codenamecurrent": "Desired State",
      "codestatuscurrent": "desiredState",
      "colorindexcurrent": "6"
    }
  ],
  "slacurrent": [
    {
      "type": "Autosys Job",
      "typehidden": "false",
      "name": "eod_settlements_debit_cdp_f6_bat",
      "namehidden": "false",
      "slatype": "Endtime SLA Violation",
      "slatypehidden": "false",
      "slavalue": "May 21 2021 | 07:20:00 PM +0530",
      "slavaluehidden": "false",
      "observedvalue": "May 21 2021 | 07:48:32 PM +0530",
      "observedvaluehidden": "false"
    }
  ],
  "sla90min": [
    {
      "type": "Autosys Job",
      "typehidden": "false",
      "name": "eod_settlements_debit_cdp_f6_bat",
      "namehidden": "false",
      "slatype": "Endtime SLA Violation",
      "slatypehidden": "false",
      "slavalue": "May 21 2021 | 07:20:00 PM +0530",
      "slavaluehidden": "false",
      "observedvalue": "May 21 2021 | 09:18:32 PM +0530",
      "observedvaluehidden": "false"
    },
    {
      "type": "Autosys Job",
      "typehidden": "false",
      "name": "process_settlements_prenote_cdp_f9_bat",
      "namehidden": "false",
      "slatype": "Endtime SLA Violation",
      "slatypehidden": "false",
      "slavalue": "May 21 2021 | 08:30:00 PM +0530",
      "slavaluehidden": "false",
      "observedvalue": "May 21 2021 | 09:48:32 PM +0530",
      "observedvaluehidden": "false"
    },
    {
      "type": "Autosys Job",
      "typehidden": "false",
      "name": "eod_settlements_end_cdp_f13_bat",
      "namehidden": "false",
      "slatype": "Endtime SLA Violation",
      "slatypehidden": "false",
      "slavalue": "May 21 2021 | 09:30:00 PM +0530",
      "slavaluehidden": "false",
      "observedvalue": "May 21 2021 | 09:48:32 PM +0530",
      "observedvaluehidden": "false"
    }
  ],
  "slacode60min": [
    {
      "codename60min": "Impacted SLA",
      "codestatus60min": "impacted",
      "colorindex60min": "4"
    },
    {
      "codename60min": "Downstream Jobs",
      "codestatus60min": "none",
      "colorindex60min": "0"
    },
    {
      "codename60min": "Failed Job",
      "codestatus60min": "fault",
      "colorindex60min": "3"
    },
    {
      "codename60min": "Desired State",
      "codestatus60min": "desiredState",
      "colorindex60min": "6"
    }
  ],
  "slaTitles": [
    {
      "title": "Impacting 1 SLA currently",
      "subtitle": "0"
    },
    {
      "title": "Impacting 2 SLA in 30 minutes",
      "subtitle": "30"
    },
    {
      "title": "Impacting 2 SLA in 60 minutes",
      "subtitle": "60"
    },
    {
      "title": "Impacting 3 SLA in 90 minutes",
      "subtitle": "90"
    }
  ],
  "sla60min": [
    {
      "type": "Autosys Job",
      "typehidden": "false",
      "name": "eod_settlements_debit_cdp_f6_bat",
      "namehidden": "false",
      "slatype": "Endtime SLA Violation",
      "slatypehidden": "false",
      "slavalue": "May 21 2021 | 07:20:00 PM +0530",
      "slavaluehidden": "false",
      "observedvalue": "May 21 2021 | 08:48:32 PM +0530",
      "observedvaluehidden": "false"
    },
    {
      "type": "Autosys Job",
      "typehidden": "false",
      "name": "process_settlements_prenote_cdp_f9_bat",
      "namehidden": "false",
      "slatype": "Endtime SLA Violation",
      "slatypehidden": "false",
      "slavalue": "May 21 2021 | 08:30:00 PM +0530",
      "slavaluehidden": "false",
      "observedvalue": "May 21 2021 | 09:18:32 PM +0530",
      "observedvaluehidden": "false"
    }
  ],
  "slacode90min": [
    {
      "codename90min": "Impacted SLA",
      "codestatus90min": "impacted",
      "colorindex90min": "4"
    },
    {
      "codename90min": "Downstream Jobs",
      "codestatus90min": "none",
      "colorindex90min": "0"
    },
    {
      "codename90min": "Failed Job",
      "codestatus90min": "fault",
      "colorindex90min": "3"
    },
    {
      "codename90min": "Desired State",
      "codestatus90min": "desiredState",
      "colorindex90min": "6"
    }
  ],
urls:{
"current":"",
"30min":""
}
}
 */

[System.Serializable]
public class ImpactSLAData
{
    public APIUrl api_urls;
    public SLACode30Min[] slacode30min;
    public SLA30Min[] sla30min;
    public SLADetails slaDetails;
    public SLACodeCurrent[] slacodecurrent;
    public SLACurrent[] slacurrent;
    public SLA90Min[] sla90min;
    public SLACode60Min[] slacode60min;
    public SLATitles[] slaTitles;
    public SLA60Min[] sla60min;
    public SLACode90Min[] slacode90min;
}

[System.Serializable]
public class APIUrl
{
    public string graph_current_url;
    public string graph_30_url;
    public string graph_60_url;
    public string graph_90_url;
}

[System.Serializable]
public class SLACode30Min
{
    public string codename30min;
    public string codestatus30min;
    public string colorindex30min;
}

[System.Serializable]
public class SLA30Min
{
    public string type;
    public string typehidden;
    public string name;
    public string namehidden;
    public string slatype;
    public string slatypehidden;
    public string slavalue;
    public string slavaluehidden;
    public string observedvalue;
    public string observedvaluehidden;
}

[System.Serializable]
public class SLADetails
{
    public string status;
    public string statushidden;
    public string faulttime;
    public string faulttimehidden;
    public string desiredendtime;
    public string desiredendtimehidden;
}

[System.Serializable]
public class SLACodeCurrent
{
    public string codenamecurrent;
    public string codestatuscurrent;
    public string colorindexcurrent;
}

[System.Serializable]
public class SLACurrent
{
    public string type;
    public string typehidden;
    public string name;
    public string namehidden;
    public string slatype;
    public string slatypehidden;
    public string slavalue;
    public string slavaluehidden;
    public string observedvalue;
    public string observedvaluehidden;
}

[System.Serializable]
public class SLA90Min
{
    public string type;
    public string typehidden;
    public string name;
    public string namehidden;
    public string slatype;
    public string slatypehidden;
    public string slavalue;
    public string slavaluehidden;
    public string observedvalue;
    public string observedvaluehidden;
}

[System.Serializable]
public class SLACode60Min
{
    public string codename60min;
    public string codestatus60min;
    public string colorindex60min;
}

[System.Serializable]
public class SLATitles
{
    public string title;
    public string subtitle;
}

[System.Serializable]
public class SLA60Min
{
    public string type;
    public string typehidden;
    public string name;
    public string namehidden;
    public string slatype;
    public string slatypehidden;
    public string slavalue;
    public string slavaluehidden;
    public string observedvalue;
    public string observedvaluehidden;
}

[System.Serializable]
public class SLACode90Min
{
    public string codename90min;
    public string codestatus90min;
    public string colorindex90min;
}


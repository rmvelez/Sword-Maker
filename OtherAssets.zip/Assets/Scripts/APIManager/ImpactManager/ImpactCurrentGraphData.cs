/*
    {
    "lastfeedtimestamp": 1621592312000,
    "graphdata": [
        {
            "entityId": "da0c754085884bba8a46e59110a5e4c0",
            "entityType": "UC4 Job",
            "entityName": "create_card_query_file_cdp_f2_bat",
            "associatedContainerName": "ign_business_intelligence_bat",
            "status": "Failed Job",
            "endTime": 1621595912000,
            "startTime": 1621592280000,
            "desiredStartTime": 1621590600000,
            "desiredEndTime": 1621594200000
        },
        {
            "entityId": "6a50113a86294ab58c185fc3a0299757",
            "entityType": "Autosys Job",
            "entityName": "process_settlements_debit_cdp_f10_bat",
            "associatedContainerName": "ign_business_intelligence_bat",
            "status": "Downstream Jobs",
            "endTime": 1621597712000,
            "startTime": 1621595912000,
            "desiredStartTime": 1621600200000,
            "desiredEndTime": 1621602000000
        },
        {
            "entityId": "1d56b47de2e44fce99abdcb528c7a520",
            "entityType": "Autosys Job",
            "entityName": "cards_accruals_cdp_f3_bat",
            "associatedContainerName": "ign_business_intelligence_bat",
            "status": "Downstream Jobs",
            "endTime": 1621599512000,
            "startTime": 1621595912000,
            "desiredStartTime": 1621594200000,
            "desiredEndTime": 1621597800000
        },
        {
            "entityId": "c574332e08074596857dbe5faea1465c",
            "entityType": "Autosys Job",
            "entityName": "process_settlements_init_cdp_f4_bat",
            "associatedContainerName": "ign_business_intelligence_bat",
            "status": "Downstream Jobs",
            "endTime": 1621599512000,
            "startTime": 1621595912000,
            "desiredStartTime": 1621594200000,
            "desiredEndTime": 1621597800000
        },
        {
            "entityId": "7b95e230e733428182f8b41e1b21d164",
            "entityType": "Autosys Job",
            "entityName": "cards_prenote_cdp_f7_bat",
            "associatedContainerName": "ign_business_intelligence_bat",
            "status": "Downstream Jobs",
            "endTime": 1621601312000,
            "startTime": 1621595912000,
            "desiredStartTime": 1621596600000,
            "desiredEndTime": 1621602000000
        },
        {
            "entityId": "265a59c9a4654ffebc0ba7b77f72ef77",
            "entityType": "Autosys Job",
            "entityName": "eod_settlements_credit_cdp_f11_bat",
            "associatedContainerName": "ign_business_intelligence_bat",
            "status": "Downstream Jobs",
            "endTime": 1621601312000,
            "startTime": 1621597712000,
            "desiredStartTime": 1621602000000,
            "desiredEndTime": 1621605600000
        },
        {
            "entityId": "b3633447fd0043799bfbb747da852054",
            "entityType": "Autosys Job",
            "entityName": "eod_settlements_init_cdp_f5_bat",
            "associatedContainerName": "ign_business_intelligence_bat",
            "status": "Downstream Jobs",
            "endTime": 1621603112000,
            "startTime": 1621599512000,
            "desiredStartTime": 1621597800000,
            "desiredEndTime": 1621601400000
        },
        {
            "entityId": "2023f9a60e4d4fdba897cabc00addcc8",
            "entityType": "Autosys Job",
            "entityName": "eod_settlements_prenote_cdp_f12_bat",
            "associatedContainerName": "ign_business_intelligence_bat",
            "status": "Downstream Jobs",
            "endTime": 1621604912000,
            "startTime": 1621601312000,
            "desiredStartTime": 1621605600000,
            "desiredEndTime": 1621609200000
        },
        {
            "entityId": "5ca5c440ce9c4ceab45cbabc022e4955",
            "entityType": "Autosys Job",
            "entityName": "process_settlements_credit_cdp_f8_bat",
            "associatedContainerName": "ign_business_intelligence_bat",
            "status": "Downstream Jobs",
            "endTime": 1621604912000,
            "startTime": 1621601312000,
            "desiredStartTime": 1621602000000,
            "desiredEndTime": 1621605600000
        },
        {
            "entityId": "142fd0e59de14b0fa1faaa51fdd224d1",
            "entityType": "Autosys Job",
            "entityName": "eod_settlements_debit_cdp_f6_bat",
            "associatedContainerName": "ign_business_intelligence_bat",
            "status": "Impacted SLA",
            "endTime": 1621606712000,
            "startTime": 1621603112000,
            "desiredStartTime": 1621601400000,
            "desiredEndTime": 1621605000000
        },
        {
            "entityId": "487e928e94bd4ae4867244b0042d4040",
            "entityType": "Autosys Job",
            "entityName": "process_settlements_prenote_cdp_f9_bat",
            "associatedContainerName": "ign_business_intelligence_bat",
            "status": "Downstream Jobs",
            "endTime": 1621608512000,
            "startTime": 1621604912000,
            "desiredStartTime": 1621605600000,
            "desiredEndTime": 1621609200000
        },
        {
            "entityId": "e3ea5bb2c1e74b41860c9444652e8802",
            "entityType": "Autosys Job",
            "entityName": "eod_settlements_end_cdp_f13_bat",
            "associatedContainerName": "ign_business_intelligence_bat",
            "status": "Downstream Jobs",
            "endTime": 1621608512000,
            "startTime": 1621604912000,
            "desiredStartTime": 1621609200000,
            "desiredEndTime": 1621612800000
        }
    ],
    "dependencyData": [
        {
            "sourceNode": "create_card_query_file_cdp_f2_bat",
            "destinationNode": "process_settlements_init_cdp_f4_bat"
        },
        {
            "sourceNode": "create_card_query_file_cdp_f2_bat",
            "destinationNode": "cards_prenote_cdp_f7_bat"
        },
        {
            "sourceNode": "create_card_query_file_cdp_f2_bat",
            "destinationNode": "cards_accruals_cdp_f3_bat"
        },
        {
            "sourceNode": "create_card_query_file_cdp_f2_bat",
            "destinationNode": "process_settlements_debit_cdp_f10_bat"
        },
        {
            "sourceNode": "process_settlements_debit_cdp_f10_bat",
            "destinationNode": "eod_settlements_credit_cdp_f11_bat"
        },
        {
            "sourceNode": "cards_accruals_cdp_f3_bat",
            "destinationNode": "eod_settlements_init_cdp_f5_bat"
        },
        {
            "sourceNode": "process_settlements_init_cdp_f4_bat",
            "destinationNode": "eod_settlements_init_cdp_f5_bat"
        },
        {
            "sourceNode": "cards_prenote_cdp_f7_bat",
            "destinationNode": "process_settlements_credit_cdp_f8_bat"
        },
        {
            "sourceNode": "eod_settlements_credit_cdp_f11_bat",
            "destinationNode": "eod_settlements_prenote_cdp_f12_bat"
        },
        {
            "sourceNode": "eod_settlements_init_cdp_f5_bat",
            "destinationNode": "eod_settlements_debit_cdp_f6_bat"
        },
        {
            "sourceNode": "eod_settlements_prenote_cdp_f12_bat",
            "destinationNode": "eod_settlements_end_cdp_f13_bat"
        },
        {
            "sourceNode": "process_settlements_credit_cdp_f8_bat",
            "destinationNode": "process_settlements_prenote_cdp_f9_bat"
        }
    ]
}
*/

[System.Serializable]
public class ImpactCurrentGraphData
{
    public double lastfeedtimestamp;
    public GraphData[] graphdata;
    public DependencyData[] dependencyData;
}

[System.Serializable]
public class GraphData
{
    public string entityId;
    public string entityType;
    public string entityName;
    public string associatedContainerName;
    public string status;
    public double endTime;
    public double startTime;
    public double desiredStartTime;
    public double desiredEndTime;
}

[System.Serializable]
public class DependencyData
{
    public string sourceNode;
    public string destinationNode;
}
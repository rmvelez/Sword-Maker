using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class ImpactGraphManager : MonoBehaviour
{
    public DataClass dataClass;
    public ImpactCurrentGraphData impactCurrentGraphData;
    public Impact30GraphData impact30GraphData;
    public Impact60GraphData impact60GraphData;
    public Impact90GraphData impact90GraphData;
    // Start is called before the first frame update
    void Start()
    {
        //ProcessAPIRequest(dataClass.configData.triageRequestUrl);
        //print("method called");
    }

    public void ProcessAPIRequest(string url)
    {
        StartCoroutine(RequestData(url));
    }

    public IEnumerator RequestData(string url)
    {
        UnityWebRequest unityWebRequest = new UnityWebRequest(url, "Get");
        unityWebRequest.downloadHandler = new DownloadHandlerBuffer();

        yield return unityWebRequest.SendWebRequest();

        if (!unityWebRequest.isNetworkError)
        {
            ProcessResponseData(unityWebRequest.downloadHandler.text);
        }
        else
        {
            Debug.Log("Error While Sending: " + unityWebRequest.error);
        }
    }

    private void ProcessResponseData(string data)
    {
        impactCurrentGraphData = JsonUtility.FromJson<ImpactCurrentGraphData>(data);
        impact30GraphData = JsonUtility.FromJson<Impact30GraphData>(data);
        impact60GraphData = JsonUtility.FromJson<Impact60GraphData>(data);
        impact90GraphData = JsonUtility.FromJson<Impact90GraphData>(data);
        //dataClass.setTriageData(triageData);
        //print("DataLoaded");
    }
}

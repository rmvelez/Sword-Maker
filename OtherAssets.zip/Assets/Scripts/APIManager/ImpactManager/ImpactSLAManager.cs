using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class ImpactSLAManager : MonoBehaviour
{
    public DataClass dataClass;
    public ImpactSLAData impactSLAData;
    // Start is called before the first frame update
    void Start()
    {
        ProcessAPIRequest(dataClass.configData.triageRequestUrl);
        print("method called");
    }

    public void ProcessAPIRequest(string url)
    {
        StartCoroutine(RequestData(url));
    }

    public IEnumerator RequestData(string url)
    {
        UnityWebRequest unityWebRequest = new UnityWebRequest(url, "Get");
        unityWebRequest.downloadHandler = new DownloadHandlerBuffer();

        yield return unityWebRequest.SendWebRequest();

        if (!unityWebRequest.isNetworkError)
        {
            ProcessResponseData(unityWebRequest.downloadHandler.text);
        }
        else
        {
            Debug.Log("Error While Sending: " + unityWebRequest.error);
        }
    }

    private void ProcessResponseData(string data)
    {
        impactSLAData = JsonUtility.FromJson<ImpactSLAData>(data);
        //dataClass.setTriageData(impactSLAData);
        //print("DataLoaded");
    }
}

/*
 {
  "bfv_content_data": [
    {
      "name": "OrderManagement",
      "slaCount": "1",
      "failCount": "3",
      "missedCount": "3",
      "status": "FAILED",
      "clickedContainerId": "b3d7420376f345ccb41fe43b777eda17",
      "rootContainerId": "b3d7420376f345ccb41fe43b777eda17",
      "type": "Business Unit",
      "completionStatus": {
        "totalJobs": 191,
        "completedJobs": 84
      },
      "predictedEndTime": "Jun 29 2021 | 02:48:32 AM +0530",
      "slaForProcessContainer": "Jun 29 2021 | 02:30:00 AM +0530",
      "predictedStartTime": "Jun 28 2021 | 05:30:00 AM +0530",
      "slaContainerStatus": "Predicted to Miss",
"speech": "The Function S L A Status is Predicted to Miss And there are 3 Failures,1 Missed S L A and 3 Predicted to miss.",
      "faults_failed_url": "/process/watch/getRealTimeExpandedView/5a2000dea9354e2a8b7fd9bb4a3c5d38/FAULTS_FAILED",
      "missed_url": "/process/watch/getRealTimeExpandedView/5a2000dea9354e2a8b7fd9bb4a3c5d38/MISSED",
      "predicted_to_miss_url": "/process/watch/getRealTimeExpandedView/5a2000dea9354e2a8b7fd9bb4a3c5d38/TOBEMISSED"
    }
  ]
}
 */

[System.Serializable]
public class BFVData
{
    public BFV_Content_Data[] bfv_content_data;
}

[System.Serializable]
public class BFV_Content_Data
{
    public string name;
    public string slaCount;
    public string failCount;
    public string missedCount;
    public string status;
    public string clickedContainerId;
    public string rootContainerId;
    public string type;
    public CompletionStatus completionStatus;
    public string predictedEndTime;
    public string slaForProcessContainer;
    public string predictedStartTime;
    public string slaContainerStatus;
    public string speech;
    public string faults_failed_url;
    public string missed_url;
    public string predicted_to_miss_url;
}

[System.Serializable]
public class CompletionStatus
{
    public int totalJobs;
    public int completedJobs;
}

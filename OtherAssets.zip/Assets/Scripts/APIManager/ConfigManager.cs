using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ConfigManager : MonoBehaviour
{
    private ConfigData configData;
    public DataClass dataclass;
    // Start is called before the first frame update
    void Awake()
    {
        TextAsset config = Resources.Load("config") as TextAsset;
        string configStr = config.ToString();
        configData = JsonUtility.FromJson<ConfigData>(configStr);
        dataclass.setConfigData(configData);
    }

    public void LoadConfigJson()
    {
        TextAsset config = Resources.Load("config") as TextAsset;
        string configStr = config.ToString();
        configData = JsonUtility.FromJson<ConfigData>(configStr);
        dataclass.setConfigData(configData);
    }
}

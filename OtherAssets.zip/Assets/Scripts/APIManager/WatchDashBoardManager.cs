using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class WatchDashBoardManager : MonoBehaviour
{
    private WatchDashBoardData watchDashBoardData;
    public WatchDataLoader dataLoader;
    public DataClass dataClass;
    public string watchId;
    // Start is called before the first frame update
    void Start()
    {
        ProcessAPIRequest(watchId, dataClass.configData.watchDashRequestUrl);
        //print(dataClass.configData.watchDashRequestUrl);
    }

    public void ProcessAPIRequest(string watchId, string url)
    {
        //dataLoader.UpdateWatchTextValue();
        StartCoroutine(RequestData(watchId, url));
    }

    public IEnumerator RequestData(string id, string apiRequestUrl)
    {
        UnityWebRequest unityWebRequest = new UnityWebRequest(apiRequestUrl, "Get");
        unityWebRequest.downloadHandler = new DownloadHandlerBuffer();

        yield return unityWebRequest.SendWebRequest();

        if (!unityWebRequest.isNetworkError)
        {
            ProcessResponseData(unityWebRequest.downloadHandler.text);
        }
        else
        {
            Debug.Log("Error While Sending: " + unityWebRequest.error);
        }

    }

    private void ProcessResponseData(string data)
    {
        watchDashBoardData = JsonUtility.FromJson<WatchDashBoardData>(data);
        dataClass.setWatchDashBoardData(watchDashBoardData);
        //dataLoader.UpdateWatchTextValue();
    }
}

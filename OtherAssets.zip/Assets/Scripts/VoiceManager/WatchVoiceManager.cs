using Microsoft.MixedReality.Toolkit.Audio;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using System.Text.RegularExpressions;
public class WatchVoiceManager : MonoBehaviour
{
    public TextToSpeech textToSpeech;

    public void Parsetext(string ss)
    {
        string speech = "";
        int temp = 0;
        string[] tempstr;
        if (int.TryParse(ss, out temp))
        {
            if (temp > 1 || temp == 0)
            {
                speech = "There are " + ss + " jobs";
            }
            else if (temp == 1)
            {
                speech = "There is " + ss + " job";
            }
        }
        else if (ss.Contains("/"))
        {
            string str = Regex.Replace(ss, @"\s", "");
            tempstr = ss.Split('/');
            speech = "There are " + tempstr[0] + " jobs out of " + tempstr[1];
        }
        else{
            speech = ss;
        }
        //print(speech);
        var msg = string.Format(speech, textToSpeech.Voice.ToString());
        textToSpeech.StartSpeaking(msg);
        
    }

    public void BFVTalk(string text)
    {
        Parsetext(text);
    }
    public void ProgressTalk(TextMeshPro valueText)
    {
        Parsetext(valueText.text.ToString());
        //Debug.Log("TextSpoken");
    }

    public void SLATalk(TextMeshPro valueText)
    {
        Parsetext(valueText.text.ToString());
        //Debug.Log("TextSpoken");
    }

    public void AnamolyTalk(TextMeshPro valueText)
    {
        Parsetext(valueText.text.ToString());
        //Debug.Log("TextSpoken");
    }

    public void CompletedTalk(TextMeshPro valueText)
    {
        Parsetext(valueText.text.ToString());
        //Debug.Log("TextSpoken");
    }

    public void MetTalk(TextMeshPro valueText)
    {
        Parsetext(valueText.text.ToString());
        //Debug.Log("TextSpoken");
    }

    public void MissedTalk(TextMeshPro valueText)
    {
        Parsetext(valueText.text.ToString());
        //Debug.Log("TextSpoken");
    }

    public void AbendTalk(TextMeshPro valueText)
    {
        Parsetext(valueText.text.ToString());
        //Debug.Log("TextSpoken");
    }

    public void InProgressTalk(TextMeshPro valueText)
    {
        Parsetext(valueText.text.ToString());
        //Debug.Log("TextSpoken");
    }

    public void FailuresTalk(TextMeshPro valueText)
    {
        Parsetext(valueText.text.ToString());
        //Debug.Log("TextSpoken");
    }

    public void OnHoldTalk(TextMeshPro valueText)
    {
        Parsetext(valueText.text.ToString());
        //Debug.Log("TextSpoken");
    }

    public void DelayedTalk(TextMeshPro valueText)
    {
        Parsetext(valueText.text.ToString());
        //Debug.Log("TextSpoken");
    }

    public void YetToStartTalk(TextMeshPro valueText)
    {
        Parsetext(valueText.text.ToString());
        //Debug.Log("TextSpoken");
    }

    public void ToMeetTalk(TextMeshPro valueText)
    {
        Parsetext(valueText.text.ToString());
        //Debug.Log("TextSpoken");
    }

    public void ToMissTalk(TextMeshPro valueText)
    {
        Parsetext(valueText.text.ToString());
        //Debug.Log("TextSpoken");
    }
}

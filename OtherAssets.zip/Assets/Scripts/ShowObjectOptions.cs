using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShowObjectOptions : MonoBehaviour
{
    public GameObject failedOptions;
    public GameObject missedOptions;
    public GameObject toMissOptions;

    public GameObject mapOptions;

    public GameObject impactButton;
    public GameObject mapsButton;
    public GameObject triageButton;

    public GameObject vitalsButton;
    public GameObject thresholdButton;
    public GameObject dependenciesButton;
    public GameObject backButton;

    public GameObject anamoliesButton_m;
    public GameObject historicBehaviourButton_m;

    public GameObject anamoliesButton_tm;
    public GameObject historicBehaviourButton_tm;
    public GameObject availabelFixButton_tm;

    public GameObject impactButton_LR;
    public GameObject mapsButton_LR;
    public GameObject triageButton_LR;

    public GameObject vitalsButton_LR;
    public GameObject thresholdButton_LR;
    public GameObject dependenciesButton_LR;
    public GameObject backButton_LR;

    public GameObject anamoliesButton_m_LR;
    public GameObject historicBehaviourButton_m_LR;

    public GameObject anamoliesButton_tm_LR;
    public GameObject historicBehaviourButton_tm_LR;
    public GameObject availabelFixButton_tm_LR;

    public float seqDelay;
    public float seqDuration;
    public float easeDuration;
    public float multiplier;

    private int failedflag;
    private int missedflag;
    private int tomissflag;

    public GameObject mapIcon;

    public GameObject failedJobNameObject;
    public GameObject missedJobNameObject;
    public GameObject toMissJobNameObject;

    public void Awake()
    {
        failedflag = 0;
        missedflag = 0;
        tomissflag = 0;
        mapOptions.SetActive(false);
        failedJobNameObject.SetActive(false);
        missedJobNameObject.SetActive(false);
        toMissJobNameObject.SetActive(false);
    }

    public void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.tag == "Failed")
        {
            ShowFailedOptions();
            //failedOptions.SetActive(true);
        }
        else if(other.gameObject.tag == "Missed")
        {
            ShowMissedOptions();
            //missedOptions.SetActive(true);
        }
        else if (other.gameObject.tag == "ToMiss")
        {
            ShowToBeMissedOptions();
            //toMissOptions.SetActive(true);
        }
    }

    public void OnTriggerStay(Collider other)
    {
        //if (other.gameObject.tag == "Failed")
        //{
        //    ShowFailedOptions();
        //    //failedOptions.SetActive(true);
        //}
        //else if (other.gameObject.tag == "Missed")
        //{
        //    ShowMissedOptions();
        //    //missedOptions.SetActive(true);
        //}
        //else if (other.gameObject.tag == "ToMiss")
        //{
        //    ShowToBeMissedOptions();
        //    //toMissOptions.SetActive(true);
        //}
    }

    public void OnTriggerExit(Collider other)
    {
        if (other.gameObject.tag == "Failed")
        {
            HideFailedOptions();
            //failedOptions.SetActive(true);
        }
        else if (other.gameObject.tag == "Missed")
        {
            HideMissedOptions();
            //missedOptions.SetActive(true);
        }
        else if (other.gameObject.tag == "ToMiss")
        {
            HideToBeMissedOptions();
            //toMissOptions.SetActive(true);
        }
    }

    public void ShowFailedOptions()
    {
        failedOptions.SetActive(true);
        
            var seq = LeanTween.sequence();
            seq.append(seqDelay);
            seq.append(LeanTween.scale(impactButton, new Vector3(400, 400, 400), seqDuration));
            seq.insert(LeanTween.scale(impactButton, new Vector3(400, 400, 400) * multiplier, easeDuration).setEasePunch());

            seq.append(LeanTween.scale(mapsButton, new Vector3(400, 400, 400), seqDuration));
            seq.insert(LeanTween.scale(mapsButton, new Vector3(400, 400, 400) * multiplier, easeDuration).setEasePunch());

            seq.append(LeanTween.scale(triageButton, new Vector3(400, 400, 400), seqDuration));
            seq.insert(LeanTween.scale(triageButton, new Vector3(400, 400, 400) * multiplier, easeDuration).setEasePunch());
            

        impactButton_LR.SetActive(true);
        mapsButton_LR.SetActive(true);
        triageButton_LR.SetActive(true);

        impactButton_LR.transform.localScale = new Vector3(400, 400, 400);
        mapsButton_LR.transform.localScale = new Vector3(400, 400, 400);
        triageButton_LR.transform.localScale = new Vector3(400, 400, 400);

        failedJobNameObject.SetActive(true);
    }

    public void ShowMapOptions()
    {
        HideFailedOptions();

        mapOptions.SetActive(true);

        mapIcon.SetActive(true);

        var seq = LeanTween.sequence();
        seq.append(seqDelay);
        seq.append(LeanTween.scale(vitalsButton, new Vector3(400, 400, 400), seqDuration));
        seq.insert(LeanTween.scale(vitalsButton, new Vector3(400, 400, 400) * multiplier, easeDuration).setEasePunch());

        seq.append(LeanTween.scale(thresholdButton, new Vector3(400, 400, 400), seqDuration));
        seq.insert(LeanTween.scale(thresholdButton, new Vector3(400, 400, 400) * multiplier, easeDuration).setEasePunch());

        seq.append(LeanTween.scale(dependenciesButton, new Vector3(400, 400, 400), seqDuration));
        seq.insert(LeanTween.scale(dependenciesButton, new Vector3(400, 400, 400) * multiplier, easeDuration).setEasePunch());

        //seq.append(LeanTween.scale(backButton, new Vector3(400, 400, 400), seqDuration));
        //seq.insert(LeanTween.scale(backButton, new Vector3(400, 400, 400) * multiplier, easeDuration).setEasePunch());


        vitalsButton_LR.SetActive(true);
        thresholdButton_LR.SetActive(true);
        dependenciesButton_LR.SetActive(true);
        //backButton_LR.SetActive(true);

        vitalsButton_LR.transform.localScale = new Vector3(400, 400, 400);
        thresholdButton_LR.transform.localScale = new Vector3(400, 400, 400);
        dependenciesButton_LR.transform.localScale = new Vector3(400, 400, 400);
        //backButton_LR.transform.localScale = new Vector3(400, 400, 400);

        backButton.SetActive(true);
    }

    public void ShowMissedOptions()
    {
        missedOptions.SetActive(true);
        
            var seq = LeanTween.sequence();
            seq.append(seqDelay);
            seq.append(LeanTween.scale(anamoliesButton_m, new Vector3(400, 400, 400), seqDuration));
            seq.insert(LeanTween.scale(anamoliesButton_m, new Vector3(400, 400, 400) * multiplier, easeDuration).setEasePunch());

            seq.append(LeanTween.scale(historicBehaviourButton_m, new Vector3(400, 400, 400), seqDuration));
            seq.insert(LeanTween.scale(historicBehaviourButton_m, new Vector3(400, 400, 400) * multiplier, easeDuration).setEasePunch());

        
        anamoliesButton_m_LR.SetActive(true);
        historicBehaviourButton_m_LR.SetActive(true);

        anamoliesButton_m_LR.transform.localScale = new Vector3(400, 400, 400);
        historicBehaviourButton_m_LR.transform.localScale = new Vector3(400, 400, 400);

        missedJobNameObject.SetActive(true);
    }

    public void ShowToBeMissedOptions()
    {
        toMissOptions.SetActive(true);
        
            var seq = LeanTween.sequence();
            seq.append(seqDelay);
            seq.append(LeanTween.scale(anamoliesButton_tm, new Vector3(400, 400, 400), seqDuration));
            seq.insert(LeanTween.scale(anamoliesButton_tm, new Vector3(400, 400, 400) * multiplier, easeDuration).setEasePunch());

            seq.append(LeanTween.scale(historicBehaviourButton_tm, new Vector3(400, 400, 400), seqDuration));
            seq.insert(LeanTween.scale(historicBehaviourButton_tm, new Vector3(400, 400, 400) * multiplier, easeDuration).setEasePunch());

            seq.append(LeanTween.scale(availabelFixButton_tm, new Vector3(400, 400, 400), seqDuration));
            seq.insert(LeanTween.scale(availabelFixButton_tm, new Vector3(400, 400, 400) * multiplier, easeDuration).setEasePunch());

       
        anamoliesButton_tm_LR.SetActive(true);
        historicBehaviourButton_tm_LR.SetActive(true);
        availabelFixButton_tm_LR.SetActive(true);

        anamoliesButton_tm_LR.transform.localScale = new Vector3(400, 400, 400);
        historicBehaviourButton_tm_LR.transform.localScale = new Vector3(400, 400, 400);
        availabelFixButton_tm_LR.transform.localScale = new Vector3(400, 400, 400);

        toMissJobNameObject.SetActive(true);
    }

    public void HideFailedOptions()
    {
        failedOptions.SetActive(true);
        var seq = LeanTween.sequence();
        seq.append(seqDelay);
        seq.append(LeanTween.scale(impactButton, Vector3.zero, seqDuration));
        seq.insert(LeanTween.scale(impactButton, Vector3.zero * multiplier, easeDuration).setEasePunch());

        seq.append(LeanTween.scale(mapsButton, Vector3.zero, seqDuration));
        seq.insert(LeanTween.scale(mapsButton, Vector3.zero * multiplier, easeDuration).setEasePunch());

        seq.append(LeanTween.scale(triageButton, Vector3.zero, seqDuration));
        seq.insert(LeanTween.scale(triageButton, Vector3.zero * multiplier, easeDuration).setEasePunch());

        impactButton_LR.SetActive(false);
        mapsButton_LR.SetActive(false);
        triageButton_LR.SetActive(false);

        impactButton_LR.transform.localScale = new Vector3(0,0,0);
        mapsButton_LR.transform.localScale = new Vector3(0, 0, 0);
        triageButton_LR.transform.localScale = new Vector3(0, 0, 0);

        failedJobNameObject.SetActive(false);
    }

    public void HideMapOptions()
    {
        mapOptions.SetActive(true);
        mapIcon.SetActive(false);
        backButton.SetActive(false);

        var seq = LeanTween.sequence();
        seq.append(seqDelay);

        seq.append(LeanTween.scale(vitalsButton, Vector3.zero, seqDuration));
        seq.insert(LeanTween.scale(vitalsButton, Vector3.zero * multiplier, easeDuration).setEasePunch());

        seq.append(LeanTween.scale(thresholdButton, Vector3.zero, seqDuration));
        seq.insert(LeanTween.scale(thresholdButton, Vector3.zero * multiplier, easeDuration).setEasePunch());

        seq.append(LeanTween.scale(dependenciesButton, Vector3.zero, seqDuration));
        seq.insert(LeanTween.scale(dependenciesButton, Vector3.zero * multiplier, easeDuration).setEasePunch());

        //seq.append(LeanTween.scale(backButton, Vector3.zero, seqDuration));
        //seq.insert(LeanTween.scale(backButton, Vector3.zero * multiplier, easeDuration).setEasePunch());

        vitalsButton_LR.SetActive(false);
        thresholdButton_LR.SetActive(false);
        dependenciesButton_LR.SetActive(false);
        //backButton_LR.SetActive(false);

        vitalsButton_LR.transform.localScale = new Vector3(0, 0, 0);
        thresholdButton_LR.transform.localScale = new Vector3(0, 0, 0);
        dependenciesButton_LR.transform.localScale = new Vector3(0, 0, 0);
        //backButton_LR.transform.localScale = new Vector3(0, 0, 0);

        ShowFailedOptions();
    }

    public void HideMissedOptions()
    {
        missedOptions.SetActive(true);
        var seq = LeanTween.sequence();
        seq.append(seqDelay);
        seq.append(LeanTween.scale(anamoliesButton_m, Vector3.zero, seqDuration));
        seq.insert(LeanTween.scale(anamoliesButton_m, Vector3.zero * multiplier, easeDuration).setEasePunch());

        seq.append(LeanTween.scale(historicBehaviourButton_m, Vector3.zero, seqDuration));
        seq.insert(LeanTween.scale(historicBehaviourButton_m, Vector3.zero * multiplier, easeDuration).setEasePunch());

        anamoliesButton_m_LR.SetActive(false);
        historicBehaviourButton_m_LR.SetActive(false);

        anamoliesButton_m_LR.transform.localScale = new Vector3(0, 0, 0);
        historicBehaviourButton_m_LR.transform.localScale = new Vector3(0, 0, 0);

        missedJobNameObject.SetActive(false);
    }

    public void HideToBeMissedOptions()
    {
        toMissOptions.SetActive(true);
        var seq = LeanTween.sequence();
        seq.append(seqDelay);
        seq.append(LeanTween.scale(anamoliesButton_tm, Vector3.zero, seqDuration));
        seq.insert(LeanTween.scale(anamoliesButton_tm, Vector3.zero * multiplier, easeDuration).setEasePunch());

        seq.append(LeanTween.scale(historicBehaviourButton_tm, Vector3.zero, seqDuration));
        seq.insert(LeanTween.scale(historicBehaviourButton_tm, Vector3.zero * multiplier, easeDuration).setEasePunch());

        seq.append(LeanTween.scale(availabelFixButton_tm, Vector3.zero, seqDuration));
        seq.insert(LeanTween.scale(availabelFixButton_tm, Vector3.zero * multiplier, easeDuration).setEasePunch());

        anamoliesButton_tm_LR.SetActive(false);
        historicBehaviourButton_tm_LR.SetActive(false);
        availabelFixButton_tm_LR.SetActive(false);

        anamoliesButton_tm_LR.transform.localScale = new Vector3(0, 0, 0);
        historicBehaviourButton_tm_LR.transform.localScale = new Vector3(0, 0, 0);
        availabelFixButton_tm_LR.transform.localScale = new Vector3(0, 0, 0);

        toMissJobNameObject.SetActive(false);
    }

    public void ResetOptions()
    {
        HideToBeMissedOptions();
        HideMissedOptions();
        HideFailedOptions();
        //HideMapOptions();
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DrawLine : MonoBehaviour
{
    // Apply these values in the editor
    LineRenderer lineRenderer;
    public Material lineMaterial;
    public Transform TransformOne;
    public Transform TransformTwo;
    public float startwidth;
    public float endwidth;
    void Start()
    {
        lineRenderer =  gameObject.GetComponent<LineRenderer>();
        lineRenderer.material = lineMaterial;
        
    }
    public void Update()
    {
            // set the color of the line
            lineRenderer.startColor = Color.green;
            lineRenderer.endColor = Color.white;

            // set width of the renderer
            lineRenderer.startWidth = startwidth;
            lineRenderer.endWidth = endwidth;

            // set the position
            lineRenderer.SetPosition(0, TransformOne.position);
            lineRenderer.SetPosition(1, TransformTwo.position);
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TimeConverter : MonoBehaviour
{
    private System.DateTime stdDateTime;
    // Start is called before the first frame update
    void Start()
    {
        stdDateTime = new System.DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);
    }

    public System.DateTime ConvertToIST(double milliseconds)
    {
        return stdDateTime.AddMilliseconds(milliseconds).ToLocalTime();
    }

    public double GetSeconds(double start, double end)
    {
        return (end - start) / 1000;
    }

    public double GetMinutes(double start, double end)
    {
        return ((end - start) / 1000) / 60;
    }

    public double GetHours(double start, double end)
    {
        return (((end - start) / 1000) / 60) / 60;
    }
}

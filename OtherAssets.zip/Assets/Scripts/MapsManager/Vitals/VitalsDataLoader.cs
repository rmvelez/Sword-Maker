using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class VitalsDataLoader : MonoBehaviour
{
    public TextMeshPro tooltip_max;
    public TextMeshPro tooltip_third_quartile;
    public TextMeshPro tooltip_mean;
    public TextMeshPro tooltip_first_quartile;
    public TextMeshPro tooltip_min;

    public TextMeshPro tooltip_average;

    public TextMeshPro tooltip_time_format;
    public TextMeshPro tooltip_timestamp;

    public void UpdateVitalsData(Mvmp_Chart_Data mvmp_chart_data)
    {
        tooltip_max.text = mvmp_chart_data.tooltip_max;
        tooltip_third_quartile.text = mvmp_chart_data.tooltip_third_quartile;
        tooltip_mean.text = mvmp_chart_data.tooltip_mean;
        tooltip_first_quartile.text = mvmp_chart_data.tooltip_first_quartile;
        tooltip_min.text = mvmp_chart_data.tooltip_min;
    }

    public void UpdateVitalsData(Mvmp_Grid_Data mvmp_grid_data)
    {
        tooltip_min.text = mvmp_grid_data.tooltip_min;
        tooltip_first_quartile.text = mvmp_grid_data.tooltip_first_quartile;
        tooltip_average.text = mvmp_grid_data.tooltip_average;
        tooltip_third_quartile.text = mvmp_grid_data.tooltip_third_quartile;
        tooltip_max.text = mvmp_grid_data.tooltip_max;
    }

    public void UpdateVitalsData(Mvmt_Coordinates mvmt_coordinates)
    {
        tooltip_time_format.text = mvmt_coordinates.tooltip_time_format;
        tooltip_timestamp.text = mvmt_coordinates.tooltip_timestamp;
    }
}

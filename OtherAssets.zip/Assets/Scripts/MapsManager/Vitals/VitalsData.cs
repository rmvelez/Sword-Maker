/*
 {
    "maps_vitals_grid":{
        "mvg_total_number_of_elements":"3",
        "mvg_data":[
            {
                "mvg_api_url":"/core/metricData?workItemId=2020-11-27-712&nodeId=da0c754085884bba8a46e59110a5e4c0&metricName=StartTimeInSecs&dynamicEntityName=ProcessHistory&outliers=0&changes=0&trends=constant&patterns=dow",
                "type":"UC4 Job",
                "name":"create_card_query_file_cdp_f2_bat",
                "metric":"Start Time",
                "average":"05:51:22",
                "change":"0",
                "last_change":"null",
                "change_directions":"null",
                "outlier":"0",
                "last_outlier":"null",
                "Trend":"Constant",
                "pattern":"Day of week"
            },
            {
                "mvg_api_url":"/core/metricData?workItemId=2020-11-27-712&nodeId=da0c754085884bba8a46e59110a5e4c0&metricName=StartTimeInSecs&dynamicEntityName=ProcessHistory&outliers=0&changes=0&trends=constant&patterns=dow",
                "type":"UC4 Job",
                "name":"create_card_query_file_cdp_f2_bat",
                "metric":"End Time",
                "average":"06:51:22",
                "change":"0",
                "last_change":"null",
                "change_directions":"null",
                "outlier":"0",
                "last_outlier":"null",
                "Trend":"Constant",
                "pattern":"Day of week"
            },
            {
                "mvg_api_url":"/core/metricData?workItemId=2020-11-27-712&nodeId=da0c754085884bba8a46e59110a5e4c0&metricName=StartTimeInSecs&dynamicEntityName=ProcessHistory&outliers=0&changes=0&trends=constant&patterns=dow",
                "type":"UC4 Job",
                "name":"create_card_query_file_cdp_f2_bat",
                "metric":"Run Time (Secs)",
                "average":"3600.0",
                "change":"0",
                "last_change":"null",
                "change_directions":"null",
                "outlier":"0",
                "last_outlier":"null",
                "Trend":"Constant",
                "pattern":"No pattern"
            }
        ]
    },
    "maps_vitals_metric_summary":{
        "title":"Start Time",
        "additionalDetails": "0  change, 0 outlier, 1 pattern, Constant trend",
        "mvms_data":[
            {
                "data": [
                    {
                        "mvms_property": "DATAVIEWER",
                        "mvms_api_url": "/core/patterns?workItemId=2020-11-27-712&nodeId=da0c754085884bba8a46e59110a5e4c0&metricName=StartTimeInSecs&downsampleType=vitals&dynamicEntityName=ProcessHistory"
                    },
                    {
                        "mvms_property": "CHART",
                        "mvms_api_url": "/core/trends?workItemId=2020-11-27-712&nodeId=da0c754085884bba8a46e59110a5e4c0&metricName=StartTimeInSecs&downsampleType=vitals&dynamicEntityName=ProcessHistory&trend=constant&changeCount=0"
                    }
                ]
            }
        ]
    },
    "maps_vitals_metric_pattern":{
        "key_findings":[
            {
                "value":"Observed pattern: "
            },
            {
                "value":"Day Of Week"
            }
            
        ],
        "disclaimerNote": "The displayed pattern has been calculated in GMT+00:00 timezone.",
        "mvmp_chart":{
            "mvmp_metric_chart":[
                {
                    "metric":"Start Time",
                    "mvmp_chart_data":[
                        {
                            "name":"Monday",
                            "max":14580000,
                            "third_quartile":12300000,
                            "mean":10649330,
                            "first_quartile":8880000,
                            "min":7140000,
                            "tooltip_max":"04:03:00",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_mean":"02:57:29",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_min":"01:59:00"
                        },
                        {
                            "name":"Tuesday",
                            "max":14580000,
                            "third_quartile":12300000,
                            "mean":10649330,
                            "first_quartile":8880000,
                            "min":7140000,
                            "tooltip_max":"04:03:00",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_mean":"02:57:29",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_min":"01:59:00"
                        },
                        {
                            "name":"Wednesday",
                            "max":14580000,
                            "third_quartile":12300000,
                            "mean":10649330,
                            "first_quartile":8880000,
                            "min":7140000,
                            "tooltip_max":"04:03:00",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_mean":"02:57:29",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_min":"01:59:00"
                        },
                        {
                            "name":"Thursday",
                            "max":14580000,
                            "third_quartile":12300000,
                            "mean":10649330,
                            "first_quartile":8880000,
                            "min":7140000,
                            "tooltip_max":"04:03:00",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_mean":"02:57:29",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_min":"01:59:00"
                        },
                        {
                            "name":"Friday",
                            "max":14580000,
                            "third_quartile":12300000,
                            "mean":10649330,
                            "first_quartile":8880000,
                            "min":7140000,
                            "tooltip_max":"04:03:00",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_mean":"02:57:29",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_min":"01:59:00"
                        },
                        {
                            "name":"Saturday",
                            "max":14580000,
                            "third_quartile":12300000,
                            "mean":10649330,
                            "first_quartile":8880000,
                            "min":7140000,
                            "tooltip_max":"04:03:00",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_mean":"02:57:29",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_min":"01:59:00"
                        },
                        {
                            "name":"Sunday",
                            "max":14580000,
                            "third_quartile":12300000,
                            "mean":10649330,
                            "first_quartile":8880000,
                            "min":7140000,
                            "tooltip_max":"04:03:00",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_mean":"02:57:29",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_min":"01:59:00"
                        }
                    ],
                    "y_axis_label":"Start Time"
                },
                {
                    "metric":"End Time",
                    "mvmp_chart_data":[
                        {
                            "name":"Monday",
                            "max":14580000,
                            "third_quartile":12300000,
                            "mean":10649330,
                            "first_quartile":8880000,
                            "min":7140000,
                            "tooltip_max":"04:03:00",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_mean":"02:57:29",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_min":"01:59:00"
                        },
                        {
                            "name":"Tuesday",
                            "max":14580000,
                            "third_quartile":12300000,
                            "mean":10649330,
                            "first_quartile":8880000,
                            "min":7140000,
                            "tooltip_max":"04:03:00",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_mean":"02:57:29",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_min":"01:59:00"
                        },
                        {
                            "name":"Wednesday",
                            "max":14580000,
                            "third_quartile":12300000,
                            "mean":10649330,
                            "first_quartile":8880000,
                            "min":7140000,
                            "tooltip_max":"04:03:00",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_mean":"02:57:29",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_min":"01:59:00"
                        },
                        {
                            "name":"Thursday",
                            "max":14580000,
                            "third_quartile":12300000,
                            "mean":10649330,
                            "first_quartile":8880000,
                            "min":7140000,
                            "tooltip_max":"04:03:00",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_mean":"02:57:29",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_min":"01:59:00"
                        },
                        {
                            "name":"Friday",
                            "max":14580000,
                            "third_quartile":12300000,
                            "mean":10649330,
                            "first_quartile":8880000,
                            "min":7140000,
                            "tooltip_max":"04:03:00",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_mean":"02:57:29",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_min":"01:59:00"
                        },
                        {
                            "name":"Saturday",
                            "max":14580000,
                            "third_quartile":12300000,
                            "mean":10649330,
                            "first_quartile":8880000,
                            "min":7140000,
                            "tooltip_max":"04:03:00",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_mean":"02:57:29",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_min":"01:59:00"
                        },
                        {
                            "name":"Sunday",
                            "max":14580000,
                            "third_quartile":12300000,
                            "mean":10649330,
                            "first_quartile":8880000,
                            "min":7140000,
                            "tooltip_max":"04:03:00",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_mean":"02:57:29",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_min":"01:59:00"
                        }
                    ],
                    "y_axis_label":"End Time"
                },
                {
                    "metric":"Run Time",
                    "mvmp_chart_data":[
                        {
                            "name":"Monday",
                            "max":14580000,
                            "third_quartile":12300000,
                            "mean":10649330,
                            "first_quartile":8880000,
                            "min":7140000,
                            "tooltip_max":"04:03:00",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_mean":"02:57:29",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_min":"01:59:00"
                        },
                        {
                            "name":"Tuesday",
                            "max":14580000,
                            "third_quartile":12300000,
                            "mean":10649330,
                            "first_quartile":8880000,
                            "min":7140000,
                            "tooltip_max":"04:03:00",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_mean":"02:57:29",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_min":"01:59:00"
                        },
                        {
                            "name":"Wednesday",
                            "max":14580000,
                            "third_quartile":12300000,
                            "mean":10649330,
                            "first_quartile":8880000,
                            "min":7140000,
                            "tooltip_max":"04:03:00",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_mean":"02:57:29",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_min":"01:59:00"
                        },
                        {
                            "name":"Thursday",
                            "max":14580000,
                            "third_quartile":12300000,
                            "mean":10649330,
                            "first_quartile":8880000,
                            "min":7140000,
                            "tooltip_max":"04:03:00",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_mean":"02:57:29",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_min":"01:59:00"
                        },
                        {
                            "name":"Friday",
                            "max":14580000,
                            "third_quartile":12300000,
                            "mean":10649330,
                            "first_quartile":8880000,
                            "min":7140000,
                            "tooltip_max":"04:03:00",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_mean":"02:57:29",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_min":"01:59:00"
                        },
                        {
                            "name":"Saturday",
                            "max":14580000,
                            "third_quartile":12300000,
                            "mean":10649330,
                            "first_quartile":8880000,
                            "min":7140000,
                            "tooltip_max":"04:03:00",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_mean":"02:57:29",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_min":"01:59:00"
                        },
                        {
                            "name":"Sunday",
                            "max":14580000,
                            "third_quartile":12300000,
                            "mean":10649330,
                            "first_quartile":8880000,
                            "min":7140000,
                            "tooltip_max":"04:03:00",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_mean":"02:57:29",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_min":"01:59:00"
                        }
                    ],
                    "y_axis_label":"Run Time"
                }
            ]
            
        },
        "mvmp_grid":{
            "mvmp_metric_gird":[
                {
                    "metric":"Start Time",
                    "mvmp_grid_data":[
                        {
                            "pattern":"Monday",
                            "tooltip_min":"01:59:00",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_average":"02:57:29",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_max":"04:03:00"
                        },
                        {
                            "pattern":"Tuesday",
                            "tooltip_min":"01:59:00",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_average":"02:57:29",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_max":"04:03:00"
                        },
                        {
                            "pattern":"Wednesday",
                            "tooltip_min":"01:59:00",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_average":"02:57:29",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_max":"04:03:00"
                        },
                        {
                            "pattern":"Thursday",
                            "tooltip_min":"01:59:00",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_average":"02:57:29",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_max":"04:03:00"
                        },
                        {
                            "pattern":"Friday",
                            "tooltip_min":"01:59:00",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_average":"02:57:29",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_max":"04:03:00"
                        },
                        {
                            "pattern":"Saturday",
                            "tooltip_min":"01:59:00",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_average":"02:57:29",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_max":"04:03:00"
                        },
                        {
                            "pattern":"Sunday",
                            "tooltip_min":"01:59:00",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_average":"02:57:29",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_max":"04:03:00"
                        }
                    ],
                    "y_axis_label":"Start Time"
                },
                {
                    "metric":"End Time",
                    "mvmp_grid_data":[
                        {
                            "pattern":"Monday",
                            "tooltip_min":"01:59:00",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_average":"02:57:29",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_max":"04:03:00"
                        },
                        {
                            "pattern":"Tuesday",
                            "tooltip_min":"01:59:00",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_average":"02:57:29",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_max":"04:03:00"
                        },
                        {
                            "pattern":"Wednesday",
                            "tooltip_min":"01:59:00",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_average":"02:57:29",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_max":"04:03:00"
                        },
                        {
                            "pattern":"Thursday",
                            "tooltip_min":"01:59:00",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_average":"02:57:29",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_max":"04:03:00"
                        },
                        {
                            "pattern":"Friday",
                            "tooltip_min":"01:59:00",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_average":"02:57:29",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_max":"04:03:00"
                        },
                        {
                            "pattern":"Saturday",
                            "tooltip_min":"01:59:00",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_average":"02:57:29",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_max":"04:03:00"
                        },
                        {
                            "pattern":"Sunday",
                            "tooltip_min":"01:59:00",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_average":"02:57:29",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_max":"04:03:00"
                        }
                    ],
                    "y_axis_label":"End Time"
                },
                {
                    "metric":"Run Time",
                    "mvmp_grid_data":[
                        {
                            "pattern":"Monday",
                            "tooltip_min":"01:59:00",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_average":"02:57:29",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_max":"04:03:00"
                        },
                        {
                            "pattern":"Tuesday",
                            "tooltip_min":"01:59:00",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_average":"02:57:29",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_max":"04:03:00"
                        },
                        {
                            "pattern":"Wednesday",
                            "tooltip_min":"01:59:00",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_average":"02:57:29",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_max":"04:03:00"
                        },
                        {
                            "pattern":"Thursday",
                            "tooltip_min":"01:59:00",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_average":"02:57:29",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_max":"04:03:00"
                        },
                        {
                            "pattern":"Friday",
                            "tooltip_min":"01:59:00",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_average":"02:57:29",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_max":"04:03:00"
                        },
                        {
                            "pattern":"Saturday",
                            "tooltip_min":"01:59:00",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_average":"02:57:29",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_max":"04:03:00"
                        },
                        {
                            "pattern":"Sunday",
                            "tooltip_min":"01:59:00",
                            "tooltip_first_quartile":"02:28:00",
                            "tooltip_average":"02:57:29",
                            "tooltip_third_quartile":"03:25:00",
                            "tooltip_max":"04:03:00"
                        }
                    ],
                    "y_axis_label":"Run Time"
                }
            ]
        }
    },
    "maps_vitals_metric_trends":{
        "key_findings":[
            {
                "value":"Observed constant trend;"
            },
            {
                "value":"Value expected to reach  03:36:40 on  Feb 11 2021 23:59:00"
            }
        ],
        "mvmt_chart":{
            "mvmt_metric_chart":[
                {
                    "metric":"Start Time",
                    "mvmt_metric_chart_data":[
                        {
                            "show_legends":false,
                            "name":"Value",
                            "color_code":"0",
                            "mvmt_coordinates":[
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                }
                            ]
                        },
                        {
                            "show_legends":true,
                            "name":"Confidence band",
                            "color_code":"1",
                            "mvmt_coordinates":[
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                }
                            ]
                        },
                        {
                            "show_legends":true,
                            "name":"Trend line",
                            "color_code":"2",
                            "mvmt_coordinates":[
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                }
                            ]
                        },
                        {
                            "show_legends":true,
                            "name":"Forecasted value",
                            "color_code":"3",
                            "mvmt_coordinates":[
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                }
                            ]
                        },
                        {
                            "show_legends":true,
                            "name":"Confidence band",
                            "color_code":"4",
                            "mvmt_coordinates":[
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                }
                            ]
                        }
                    ]
                },
                {
                    "metric":"End Time",
                    "mvmt_metric_chart_data":[
                        {
                            "show_legends":false,
                            "name":"Value",
                            "color_code":"0",
                            "mvmt_coordinates":[
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                }
                            ]
                        },
                        {
                            "show_legends":true,
                            "name":"Confidence band",
                            "color_code":"1",
                            "mvmt_coordinates":[
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                }
                            ]
                        },
                        {
                            "show_legends":true,
                            "name":"Trend line",
                            "color_code":"2",
                            "mvmt_coordinates":[
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                }
                            ]
                        },
                        {
                            "show_legends":true,
                            "name":"Forecasted value",
                            "color_code":"3",
                            "mvmt_coordinates":[
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                }
                            ]
                        },
                        {
                            "show_legends":true,
                            "name":"Confidence band",
                            "color_code":"4",
                            "mvmt_coordinates":[
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                }
                            ]
                        }
                    ]
                },
                {
                    "metric":"Run Time",
                    "mvmt_metric_chart_data":[
                        {
                            "show_legends":false,
                            "name":"Value",
                            "color_code":"0",
                            "mvmt_coordinates":[
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                }
                            ]
                        },
                        {
                            "show_legends":true,
                            "name":"Confidence band",
                            "color_code":"1",
                            "mvmt_coordinates":[
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                }
                            ]
                        },
                        {
                            "show_legends":true,
                            "name":"Trend line",
                            "color_code":"2",
                            "mvmt_coordinates":[
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                }
                            ]
                        },
                        {
                            "show_legends":true,
                            "name":"Forecasted value",
                            "color_code":"3",
                            "mvmt_coordinates":[
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                }
                            ]
                        },
                        {
                            "show_legends":true,
                            "name":"Confidence band",
                            "color_code":"4",
                            "mvmt_coordinates":[
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.856237E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"00:48:33"
                                }
                            ]
                        }
                    ]
                }
                
            ]
        }
    },
    "maps_vitals_metric_change":{

    },
    "maps_vitals_metric_outlier":{

    }
}
 */

[System.Serializable]
public class VitalsData
{
    public Maps_Vitals_Grid[] maps_vitals_grid;
    public Maps_Vitals_Metric_Summary[] maps_vitals_metric_summary;
    public Maps_Vitals_Metric_Pattern[] maps_vitals_metric_pattern;
    public Maps_Vitals_Metric_Trends[] maps_vitals_metric_trends;
    public Maps_Vitals_Metric_Change[] maps_vitals_metric_change;
    public Maps_Vitals_Metric_Outlier[] maps_vitals_metric_outlier;
}

[System.Serializable]
public class Maps_Vitals_Grid
{
    public string mvg_total_number_of_elements;
    public Mvg_Data[] mvg_data;
}

[System.Serializable]
public class Mvg_Data
{
    public string mvg_api_url;
    public string type;
    public string name;
    public string metric;
    public string average;
    public string change;
    public string last_change;
    public string change_directions;
    public string outlier;
    public string last_outlier;
    public string Trend;
    public string pattern;
}

[System.Serializable]
public class Maps_Vitals_Metric_Summary
{
    public string title;
    public string additionalDetails;
    public Mvms_Data[] mvms_data;
}

[System.Serializable]
public class Mvms_Data
{
    public Data[] data;
}

[System.Serializable]
public class Data
{
    public string mvms_property;
    public string mvms_api_url;
}

[System.Serializable]
public class Maps_Vitals_Metric_Pattern
{
    public Key_Findings[] key_findings;
    public string disclaimerNote;
    public Mvmp_Chart[] mvmp_chart;
    public Mvmp_Grid[] mvmp_gird;
}

[System.Serializable]
public class Key_Findings
{
    public string value;
}

[System.Serializable]
public class Mvmp_Chart
{
    public Mvmp_Metric_Chart[] mvmp_metric_chart;
}

[System.Serializable]
public class Mvmp_Metric_Chart
{
    public string metric;
    public Mvmp_Chart_Data[] mvmp_chart_data;
    public string y_axis_data;
}

[System.Serializable]
public class Mvmp_Chart_Data
{
    public string name;
    public int max;
    public int third_quartile;
    public int mean;
    public int first_quartile;
    public int min;
    public string tooltip_max;
    public string tooltip_third_quartile;
    public string tooltip_mean;
    public string tooltip_first_quartile;
    public string tooltip_min;
}

[System.Serializable]
public class Mvmp_Grid
{
    public Mvmp_Metric_Grid[] mvmp_metric_grid;
}

[System.Serializable]
public class Mvmp_Metric_Grid
{
    public string metric;
    public Mvmp_Grid_Data[] mvmp_grid_data;
    public string y_axis_label;
}

[System.Serializable]
public class Mvmp_Grid_Data
{
    public string pattern;
    public string tooltip_min;
    public string tooltip_first_quartile;
    public string tooltip_average;
    public string tooltip_third_quartile;
    public string tooltip_max;
}

[System.Serializable]
public class Maps_Vitals_Metric_Trends
{
    public Key_Findings[] key_findings;
    public Mvmt_Chart[] mvmt_chart;
}

[System.Serializable]
public class Mvmt_Chart
{
    public Mvmt_Metric_Chart[] mvmt_metric_chart;
}

[System.Serializable]
public class Mvmt_Metric_Chart
{
    public string metric;
    public Mvmt_Metric_Chart_Data[] mvmt_metric_chart_data;
}

[System.Serializable]
public class Mvmt_Metric_Chart_Data
{
    public bool show_legends;
    public string name;
    public string color_code;
    public Mvmt_Coordinates[] mvmt_coordinates;
}

[System.Serializable]
public class Mvmt_Coordinates
{
    public string yaxis;
    public string xaxis;
    public string tooltip_time_format;
    public string tooltip_timestamp;
}

[System.Serializable]
public class Maps_Vitals_Metric_Change
{

}

[System.Serializable]
public class Maps_Vitals_Metric_Outlier
{

}

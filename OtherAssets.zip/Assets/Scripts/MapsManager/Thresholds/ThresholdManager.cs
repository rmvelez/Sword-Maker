using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class ThresholdManager : MonoBehaviour
{
    public ThresholdData thresholdData;
    public DataClass dataClass;
    // Start is called before the first frame update
    void Start()
    {
        //ProcessAPIRequest(dataClass.configData.thresholdRequestUrl);
    }

    public void ProcessAPIRequest(string url)
    {
        StartCoroutine(RequestData(url));
    }

    public IEnumerator RequestData(string url)
    {
        UnityWebRequest unityWebRequest = new UnityWebRequest(url, "Get");
        unityWebRequest.downloadHandler = new DownloadHandlerBuffer();

        yield return unityWebRequest.SendWebRequest();

        if (!unityWebRequest.isNetworkError)
        {
            ProcessResponseData(unityWebRequest.downloadHandler.text);
        }
        else
        {
            Debug.Log("Error While Sending: " + unityWebRequest.error);
        }

    }

    private void ProcessResponseData(string data)
    {
        thresholdData = JsonUtility.FromJson<ThresholdData>(data);
        dataClass.setThresholdData(thresholdData);
    }
}

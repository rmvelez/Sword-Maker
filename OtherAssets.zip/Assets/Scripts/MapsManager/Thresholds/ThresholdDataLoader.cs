using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class ThresholdDataLoader : MonoBehaviour
{
    public TextMeshPro tooltip_current_threshold;
    public TextMeshPro tooltip_current_timestamp;
    public TextMeshPro tooltip_ignio_threshold;
    public TextMeshPro tooltip_ignio_timestamp;

    public TextMeshPro tooltip_time_format;
    public TextMeshPro tooltip_timestamp;

    public void UpdateThresholdData(Mter_Coordinates mter_coordinates)
    {
        tooltip_current_threshold.text = mter_coordinates.tooltip_current_threshold;
        tooltip_current_timestamp.text = mter_coordinates.tooltip_current_timestamp;
        tooltip_ignio_threshold.text = mter_coordinates.tooltip_ignio_threshold;
        tooltip_ignio_timestamp.text = mter_coordinates.tooltip_ignio_timestamp;
    }

    public void UpdateThresholdData(Mtega_Coordinates mtega_coordinates)
    {
        tooltip_time_format.text = mtega_coordinates.tooltip_time_format;
        tooltip_timestamp.text = mtega_coordinates.tooltip_timestamp;
    }
}

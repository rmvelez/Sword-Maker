/*
 {
    "maps_threshold_evidence":{
        "mte_details":[
            {
                "property": "Alerts with ignio thresholds",
                "value": "2"
            },
            {
                "property": "Alerts with current thresholds",
                "value": "32"
            }
        ],
        "mter_chart_bar":{
            "mter_metric_chart_bar":[
                {
                    "yAxisLabel": "Start Time",
                    "xAxisLabel": "Day of week",
                    "mter_coordinates":[
                        {
                            "name":"Monday",
                            "current_threshold":"48600000",
                            "tooltip_current_threshold":"Current threshold",
                            "tooltip_current_timestamp":"13:30:00",
                            "ignio_threshold":"14967000",
                            "tooltip_ignio_threshold":"ignio threshold",
                            "tooltip_ignio_timestamp":"04:09:27"
                        },
                        {
                            "name":"Tuesday",
                            "current_threshold":"48600000",
                            "tooltip_current_threshold":"Current threshold",
                            "tooltip_current_timestamp":"13:30:00",
                            "ignio_threshold":"14967000",
                            "tooltip_ignio_threshold":"ignio threshold",
                            "tooltip_ignio_timestamp":"04:09:27"
                        },
                        {
                            "name":"Wednesday",
                            "current_threshold":"48600000",
                            "tooltip_current_threshold":"Current threshold",
                            "tooltip_current_timestamp":"13:30:00",
                            "ignio_threshold":"14967000",
                            "tooltip_ignio_threshold":"ignio threshold",
                            "tooltip_ignio_timestamp":"04:09:27"
                        },
                        {
                            "name":"Thursday",
                            "current_threshold":"48600000",
                            "tooltip_current_threshold":"Current threshold",
                            "tooltip_current_timestamp":"13:30:00",
                            "ignio_threshold":"14967000",
                            "tooltip_ignio_threshold":"ignio threshold",
                            "tooltip_ignio_timestamp":"04:09:27"
                        },
                        {
                            "name":"Friday",
                            "current_threshold":"48600000",
                            "tooltip_current_threshold":"Current threshold",
                            "tooltip_current_timestamp":"13:30:00",
                            "ignio_threshold":"14967000",
                            "tooltip_ignio_threshold":"ignio threshold",
                            "tooltip_ignio_timestamp":"04:09:27"
                        },
                        {
                            "name":"Saturday",
                            "current_threshold":"48600000",
                            "tooltip_current_threshold":"Current threshold",
                            "tooltip_current_timestamp":"13:30:00",
                            "ignio_threshold":"14967000",
                            "tooltip_ignio_threshold":"ignio threshold",
                            "tooltip_ignio_timestamp":"04:09:27"
                        },
                        {
                            "name":"Sunday",
                            "current_threshold":"48600000",
                            "tooltip_current_threshold":"Current threshold",
                            "tooltip_current_timestamp":"13:30:00",
                            "ignio_threshold":"14967000",
                            "tooltip_ignio_threshold":"ignio threshold",
                            "tooltip_ignio_timestamp":"04:09:27"
                        }
                    ]
                },
                {
                    "yAxisLabel": "End Time",
                    "xAxisLabel": "Day of week",
                    "mter_coordinates":[
                        {
                            "name":"Monday",
                            "current_threshold":"48600000",
                            "tooltip_current_threshold":"Current threshold",
                            "tooltip_current_timestamp":"13:30:00",
                            "ignio_threshold":"14967000",
                            "tooltip_ignio_threshold":"ignio threshold",
                            "tooltip_ignio_timestamp":"04:09:27"
                        },
                        {
                            "name":"Tuesday",
                            "current_threshold":"48600000",
                            "tooltip_current_threshold":"Current threshold",
                            "tooltip_current_timestamp":"13:30:00",
                            "ignio_threshold":"14967000",
                            "tooltip_ignio_threshold":"ignio threshold",
                            "tooltip_ignio_timestamp":"04:09:27"
                        },
                        {
                            "name":"Wednesday",
                            "current_threshold":"48600000",
                            "tooltip_current_threshold":"Current threshold",
                            "tooltip_current_timestamp":"13:30:00",
                            "ignio_threshold":"14967000",
                            "tooltip_ignio_threshold":"ignio threshold",
                            "tooltip_ignio_timestamp":"04:09:27"
                        },
                        {
                            "name":"Thursday",
                            "current_threshold":"48600000",
                            "tooltip_current_threshold":"Current threshold",
                            "tooltip_current_timestamp":"13:30:00",
                            "ignio_threshold":"14967000",
                            "tooltip_ignio_threshold":"ignio threshold",
                            "tooltip_ignio_timestamp":"04:09:27"
                        },
                        {
                            "name":"Friday",
                            "current_threshold":"48600000",
                            "tooltip_current_threshold":"Current threshold",
                            "tooltip_current_timestamp":"13:30:00",
                            "ignio_threshold":"14967000",
                            "tooltip_ignio_threshold":"ignio threshold",
                            "tooltip_ignio_timestamp":"04:09:27"
                        },
                        {
                            "name":"Saturday",
                            "current_threshold":"48600000",
                            "tooltip_current_threshold":"Current threshold",
                            "tooltip_current_timestamp":"13:30:00",
                            "ignio_threshold":"14967000",
                            "tooltip_ignio_threshold":"ignio threshold",
                            "tooltip_ignio_timestamp":"04:09:27"
                        },
                        {
                            "name":"Sunday",
                            "current_threshold":"48600000",
                            "tooltip_current_threshold":"Current threshold",
                            "tooltip_current_timestamp":"13:30:00",
                            "ignio_threshold":"14967000",
                            "tooltip_ignio_threshold":"ignio threshold",
                            "tooltip_ignio_timestamp":"04:09:27"
                        }
                    ]
                },
                {
                    "yAxisLabel": "Run Time",
                    "xAxisLabel": "Day of week",
                    "mter_coordinates":[
                        {
                            "name":"Monday",
                            "current_threshold":"48600000",
                            "tooltip_current_threshold":"Current threshold",
                            "tooltip_current_timestamp":"13:30:00",
                            "ignio_threshold":"14967000",
                            "tooltip_ignio_threshold":"ignio threshold",
                            "tooltip_ignio_timestamp":"04:09:27"
                        },
                        {
                            "name":"Tuesday",
                            "current_threshold":"48600000",
                            "tooltip_current_threshold":"Current threshold",
                            "tooltip_current_timestamp":"13:30:00",
                            "ignio_threshold":"14967000",
                            "tooltip_ignio_threshold":"ignio threshold",
                            "tooltip_ignio_timestamp":"04:09:27"
                        },
                        {
                            "name":"Wednesday",
                            "current_threshold":"48600000",
                            "tooltip_current_threshold":"Current threshold",
                            "tooltip_current_timestamp":"13:30:00",
                            "ignio_threshold":"14967000",
                            "tooltip_ignio_threshold":"ignio threshold",
                            "tooltip_ignio_timestamp":"04:09:27"
                        },
                        {
                            "name":"Thursday",
                            "current_threshold":"48600000",
                            "tooltip_current_threshold":"Current threshold",
                            "tooltip_current_timestamp":"13:30:00",
                            "ignio_threshold":"14967000",
                            "tooltip_ignio_threshold":"ignio threshold",
                            "tooltip_ignio_timestamp":"04:09:27"
                        },
                        {
                            "name":"Friday",
                            "current_threshold":"48600000",
                            "tooltip_current_threshold":"Current threshold",
                            "tooltip_current_timestamp":"13:30:00",
                            "ignio_threshold":"14967000",
                            "tooltip_ignio_threshold":"ignio threshold",
                            "tooltip_ignio_timestamp":"04:09:27"
                        },
                        {
                            "name":"Saturday",
                            "current_threshold":"48600000",
                            "tooltip_current_threshold":"Current threshold",
                            "tooltip_current_timestamp":"13:30:00",
                            "ignio_threshold":"14967000",
                            "tooltip_ignio_threshold":"ignio threshold",
                            "tooltip_ignio_timestamp":"04:09:27"
                        },
                        {
                            "name":"Sunday",
                            "current_threshold":"48600000",
                            "tooltip_current_threshold":"Current threshold",
                            "tooltip_current_timestamp":"13:30:00",
                            "ignio_threshold":"14967000",
                            "tooltip_ignio_threshold":"ignio threshold",
                            "tooltip_ignio_timestamp":"04:09:27"
                        }
                    ]
                }
            ]
        },
        "mtega_chart_line":{
            "mtega_metric_chart_line":[
                {
                    "yAxisLabel": "Start Time",
                    "title": "Generated alerts",
                    "mtega_metric_chart_line_data":[
                        {
                            "showlegend":true,
                            "representation_type":"Line",
                            "name":"Start Time",
                            "color_code":"0",
                            "mtega_coordinates":[
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.188E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"03:18:00"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.188E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"03:18:00"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.188E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"03:18:00"
                                }
                            ]
                        },
                        {
                            "showlegend":true,
                            "representation_type":"Line",
                            "name":"Current threshold",
                            "color_code":"0",
                            "mtega_coordinates":[
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.188E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"03:18:00"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.188E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"03:18:00"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.188E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"03:18:00"
                                }
                            ]
                        },
                        {
                            "showlegend":true,
                            "representation_type":"Line",
                            "name":"ignio threshold",
                            "color_code":"0",
                            "mtega_coordinates":[
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.188E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"03:18:00"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.188E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"03:18:00"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.188E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"03:18:00"
                                }
                            ]
                        },
                        {
                            "showlegend":true,
                            "representation_type":"Line",
                            "name":"Alerts-current threshold",
                            "color_code":"0",
                            "mtega_coordinates":[
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.188E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"03:18:00"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.188E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"03:18:00"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.188E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"03:18:00"
                                }
                            ]
                        },
                        {
                            "showlegend":true,
                            "representation_type":"Line",
                            "name":"Alerts-ignio threshold",
                            "color_code":"0",
                            "mtega_coordinates":[
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.188E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"03:18:00"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.188E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"03:18:00"
                                },
                                {
                                    "yaxis":"1577848680000",
                                    "xaxis":"1.188E7",
                                    "tooltip_time_format":"Time in HH:MM:SS ",
                                    "tooltip_timestamp":"03:18:00"
                                }
                            ]
                        }
                    ]
                }
            ]
        },
        "mte_grid_data":[
            {
                "property":"Day of week",
                "property_value":"Monday",
                "current_threshold":"13:30:00",
                "ignio_threshold":"04:09:27"
            },
            {
                "property":"Day of week",
                "property_value":"Tuesday",
                "current_threshold":"13:30:00",
                "ignio_threshold":"04:09:27"
            },
            {
                "property":"Day of week",
                "property_value":"Wednesday",
                "current_threshold":"13:30:00",
                "ignio_threshold":"04:09:27"
            },
            {
                "property":"Day of week",
                "property_value":"Thursday",
                "current_threshold":"13:30:00",
                "ignio_threshold":"04:09:27"
            },
            {
                "property":"Day of week",
                "property_value":"Friday",
                "current_threshold":"13:30:00",
                "ignio_threshold":"04:09:27"
            },
            {
                "property":"Day of week",
                "property_value":"Saturday",
                "current_threshold":"13:30:00",
                "ignio_threshold":"04:09:27"
            },
            {
                "property":"Day of week",
                "property_value":"Sunday",
                "current_threshold":"13:30:00",
                "ignio_threshold":"04:09:27"
            }
        ]
    },
    "maps_threshold_grid":{
        "mtg_total_number_of_elements":3,
        "mtg_grid_data":[
            {
                "type":"UC4 Job",
                "name":"create_card_query_file_cdp_f2_bat",
                "metric_name":"Start Time",
                "alerts_with_ignio_thresholds":"2",
                "alerts_with_current_thresholds":"32",
                "threshold_type":"Dynamic",
                "pattern":"Day of week",
                "mtg_api_url":"/core/getThresholdsEvidenceView?nodeId=da0c754085884bba8a46e59110a5e4c0&nodeType=UC4Job&metricName=StartTimeInSecs&workItemId=2020-12-05-774&dynamicEntityName=ProcessHistory&afterAnalysisFlag=FALSE"
            },
            {
                "type":"UC4 Job",
                "name":"create_card_query_file_cdp_f2_bat",
                "metric_name":"End Time",
                "alerts_with_ignio_thresholds":"2",
                "alerts_with_current_thresholds":"32",
                "threshold_type":"Dynamic",
                "pattern":"Day of week",
                "mtg_api_url":"/core/getThresholdsEvidenceView?nodeId=da0c754085884bba8a46e59110a5e4c0&nodeType=UC4Job&metricName=StartTimeInSecs&workItemId=2020-12-05-774&dynamicEntityName=ProcessHistory&afterAnalysisFlag=FALSE"
            },
            {
                "type":"UC4 Job",
                "name":"create_card_query_file_cdp_f2_bat",
                "metric_name":"Run Time (Secs)",
                "alerts_with_ignio_thresholds":"0",
                "alerts_with_current_thresholds":"-",
                "threshold_type":"Static",
                "pattern":"Day of week",
                "mtg_api_url":"/core/getThresholdsEvidenceView?nodeId=da0c754085884bba8a46e59110a5e4c0&nodeType=UC4Job&metricName=StartTimeInSecs&workItemId=2020-12-05-774&dynamicEntityName=ProcessHistory&afterAnalysisFlag=FALSE"
            }
        ]
    }
}
 */

[System.Serializable]
public class ThresholdData
{
    public Maps_Threshold_Evidence[] maps_threshold_evidence;
    public Maps_Threshold_Grid[] maps_threshold_grid;
}

[System.Serializable]
public class Maps_Threshold_Evidence
{
    public Mte_Details[] mte_details;
    public Mter_Chart_Bar[] mter_chart_bar;
    public Mtega_Chart_Line[] mtega_chart_line;
    public Mte_Grid_Data[] mte_grid_data;
}

[System.Serializable]
public class Mte_Details
{
    public string property;
    public string value;
}

[System.Serializable]
public class Mter_Chart_Bar
{
    public Mter_Metric_Chart_Bar[] mter_metric_chart_bar;
}

[System.Serializable]
public class Mter_Metric_Chart_Bar
{
    public string yAxisLabel;
    public string xAxisLabel;
    public Mter_Coordinates[] mter_coordinates;
}

[System.Serializable]
public class Mter_Coordinates
{
    public string name;
    public string current_threshold;
    public string tooltip_current_threshold;
    public string tooltip_current_timestamp;
    public string ignio_threshold;
    public string tooltip_ignio_threshold;
    public string tooltip_ignio_timestamp;
}

[System.Serializable]
public class Mtega_Chart_Line
{
    public Mtega_Metric_Chart_Line[] mtega_metric_chart_line;
}

[System.Serializable]
public class Mtega_Metric_Chart_Line
{
    public string yAxisLabel;
    public string title;
    public Mtega_Metric_Chart_Line_Data[] mtega_metric_chart_line_data;
}

[System.Serializable]
public class Mtega_Metric_Chart_Line_Data
{
    public bool showlegend;
    public string representation_type;
    public string name;
    public string color_code;
    public Mtega_Coordinates[] mtega_coordinates;
}

[System.Serializable]
public class Mtega_Coordinates
{
    public string yaxis;
    public string xaxis;
    public string tooltip_time_format;
    public string tooltip_timestamp;
}

[System.Serializable]
public class Mte_Grid_Data
{
    public string property;
    public string property_value;
    public string current_threshold;
    public string ignio_threshold;
}

[System.Serializable]
public class Maps_Threshold_Grid
{
    public int mtg_total_number_of_elements;
    public Mtg_Grid_Data[] mtg_grid_data;
}

[System.Serializable]
public class Mtg_Grid_Data
{
    public string type;
    public string name;
    public string metric_name;
    public string alerts_with_ignio_thresholds;
    public string alerts_with_current_thresholds;
    public string threshold_type;
    public string pattern;
    public string mtg_api_url;
}
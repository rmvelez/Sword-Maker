using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapsViewManager : MonoBehaviour
{
    public GameObject vitalsView;
    public GameObject thresholdView;
    public GameObject dependView;

    public GameObject mapsOptions;

    // Start is called before the first frame update
    void Start()
    {
        vitalsView.SetActive(false);
        thresholdView.SetActive(false);
        dependView.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void ShowVitals()
    {
        vitalsView.SetActive(true);
        mapsOptions.SetActive(false);
    }

    public void ShowThreshold()
    {
        thresholdView.SetActive(true);
        mapsOptions.SetActive(false);
    }

    public void ShowDependencies()
    {
        dependView.SetActive(true);
        mapsOptions.SetActive(false);
    }

    public void HideVitals()
    {
        vitalsView.SetActive(false);
        mapsOptions.SetActive(true);
    }

    public void HideThreshold()
    {
        thresholdView.SetActive(false);
        mapsOptions.SetActive(true);
    }

    public void HideDependencies()
    {
        dependView.SetActive(false);
        mapsOptions.SetActive(true);
    }
}

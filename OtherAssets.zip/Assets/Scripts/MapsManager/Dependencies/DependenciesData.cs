/*
 {
    "maps_dependencies_grid":{
        "mdg_data":{
            "mdg_api_url":"/core/getDependeciesEvidenceView?nodeId=da0c754085884bba8a46e59110a5e4c0&caption=create_card_query_file_cdp_f2_bat&label=UC4Job",
            "uptree_node":1,
            "downtree_node":11,
            "sibiling_node":0
        }        
    },
    "maps_dependencies_tree":{
        "mdt_data":[
            {
                "title":"Uptree node",
                "key_findings":"1 Uptree node",
                "graph_type":"Uptree",
                "no_of_levels":1,
                "legend_chart_data":[
                    {
                        "group_name":"Target node",
                        "group":1
                    },
                    {
                        "group_name":"Uptree node",
                        "group":0
                    }
                ],
                "legend_tree_node_data":[
                    {
                        "id":"93923cbd92dc468a87fdd516ec8734f3",
                        "display_name":"cards_settlements_start_cdp_f1_bat|AutosysJob",
                        "level":-1,
                        "group":0
                    },
                    {
                        "id":"da0c754085884bba8a46e59110a5e4c0",
                        "display_name":"create_card_query_file_cdp_f2_bat|UC4Job",
                        "level":0,
                        "group":1
                    }
                ],
                "legend_tree_edge_data":[
                    {
                        "source":"da0c754085884bba8a46e59110a5e4c0",
                        "target":"93923cbd92dc468a87fdd516ec8734f3"
                    }
                ]
            },
            {
                "title":"Downtree node",
                "key_findings":"11 Downtree node",
                "graph_type":"Downtree",
                "no_of_levels":4,
                "legend_chart_data":[
                    {
                        "group_name":"Target node",
                        "group":1
                    },
                    {
                        "group_name":"Downtree node",
                        "group":0
                    }
                ],
                "legend_tree_node_data":[
                    {
                        "id": "b3633447fd0043799bfbb747da852054",
                        "display_name": "eod_settlements_init_cdp_f5_bat|AutosysJob",
                        "level": 2,
                        "group": 0
                      },
                      {
                        "id": "5ca5c440ce9c4ceab45cbabc022e4955",
                        "display_name": "process_settlements_credit_cdp_f8_bat|AutosysJob",
                        "level": 2,
                        "group": 0
                      },
                      {
                        "id": "6a50113a86294ab58c185fc3a0299757",
                        "display_name": "process_settlements_debit_cdp_f10_bat|AutosysJob",
                        "level": 1,
                        "group": 0
                      },
                      {
                        "id": "da0c754085884bba8a46e59110a5e4c0",
                        "display_name": "create_card_query_file_cdp_f2_bat|UC4Job",
                        "level": 0,
                        "group": 1
                      },
                      {
                        "id": "265a59c9a4654ffebc0ba7b77f72ef77",
                        "display_name": "eod_settlements_credit_cdp_f11_bat|AutosysJob",
                        "level": 2,
                        "group": 0
                      },
                      {
                        "id": "c574332e08074596857dbe5faea1465c",
                        "display_name": "process_settlements_init_cdp_f4_bat|AutosysJob",
                        "level": 1,
                        "group": 0
                      },
                      {
                        "id": "142fd0e59de14b0fa1faaa51fdd224d1",
                        "display_name": "eod_settlements_debit_cdp_f6_bat|AutosysJob",
                        "level": 3,
                        "group": 0
                      },
                      {
                        "id": "1d56b47de2e44fce99abdcb528c7a520",
                        "display_name": "cards_accruals_cdp_f3_bat|AutosysJob",
                        "level": 1,
                        "group": 0
                      },
                      {
                        "id": "e3ea5bb2c1e74b41860c9444652e8802",
                        "display_name": "eod_settlements_end_cdp_f13_bat|AutosysJob",
                        "level": 4,
                        "group": 0
                      },
                      {
                        "id": "7b95e230e733428182f8b41e1b21d164",
                        "display_name": "cards_prenote_cdp_f7_bat|AutosysJob",
                        "level": 1,
                        "group": 0
                      },
                      {
                        "id": "2023f9a60e4d4fdba897cabc00addcc8",
                        "display_name": "eod_settlements_prenote_cdp_f12_bat|AutosysJob",
                        "level": 3,
                        "group": 0
                      },
                      {
                        "id": "487e928e94bd4ae4867244b0042d4040",
                        "display_name": "process_settlements_prenote_cdp_f9_bat|AutosysJob",
                        "level": 3,
                        "group": 0
                      }
                ],
                "legend_tree_edge_data":[
                    {
                        "source": "da0c754085884bba8a46e59110a5e4c0",
                        "target": "c574332e08074596857dbe5faea1465c"
                      },
                      {
                        "source": "c574332e08074596857dbe5faea1465c",
                        "target": "b3633447fd0043799bfbb747da852054"
                      },
                      {
                        "source": "b3633447fd0043799bfbb747da852054",
                        "target": "142fd0e59de14b0fa1faaa51fdd224d1"
                      },
                      {
                        "source": "da0c754085884bba8a46e59110a5e4c0",
                        "target": "7b95e230e733428182f8b41e1b21d164"
                      },
                      {
                        "source": "7b95e230e733428182f8b41e1b21d164",
                        "target": "5ca5c440ce9c4ceab45cbabc022e4955"
                      },
                      {
                        "source": "5ca5c440ce9c4ceab45cbabc022e4955",
                        "target": "487e928e94bd4ae4867244b0042d4040"
                      },
                      {
                        "source": "da0c754085884bba8a46e59110a5e4c0",
                        "target": "1d56b47de2e44fce99abdcb528c7a520"
                      },
                      {
                        "source": "1d56b47de2e44fce99abdcb528c7a520",
                        "target": "b3633447fd0043799bfbb747da852054"
                      },
                      {
                        "source": "da0c754085884bba8a46e59110a5e4c0",
                        "target": "6a50113a86294ab58c185fc3a0299757"
                      },
                      {
                        "source": "6a50113a86294ab58c185fc3a0299757",
                        "target": "265a59c9a4654ffebc0ba7b77f72ef77"
                      },
                      {
                        "source": "265a59c9a4654ffebc0ba7b77f72ef77",
                        "target": "2023f9a60e4d4fdba897cabc00addcc8"
                      },
                      {
                        "source": "2023f9a60e4d4fdba897cabc00addcc8",
                        "target": "e3ea5bb2c1e74b41860c9444652e8802"
                      }
                ]
            },
            {
                "title":"Sibling node",
                "key_findings":"0 Sibling node",
                "graph_type":"Sibling",
                "no_of_levels":1,
                "legend_chart_data":[
                    {
                        "group_name":"Target node",
                        "group":1
                    },
                    {
                        "group_name":"Sibling node",
                        "group":2
                    }
                ],
                "legend_tree_node_data":[
                    {
                        "id": "93923cbd92dc468a87fdd516ec8734f3",
                        "display_name": "cards_settlements_start_cdp_f1_bat|AutosysJob",
                        "level": -1,
                        "group": 2
                      },
                      {
                        "id": "da0c754085884bba8a46e59110a5e4c0",
                        "display_name": "create_card_query_file_cdp_f2_bat|UC4Job",
                        "level": 0,
                        "group": 1
                      }
                ],
                "legend_tree_edge_data":[
                    {
                        "source": "93923cbd92dc468a87fdd516ec8734f3",
                        "target": "93923cbd92dc468a87fdd516ec8734f3"
                      },
                      {
                        "source": "da0c754085884bba8a46e59110a5e4c0",
                        "target": "93923cbd92dc468a87fdd516ec8734f3"
                      }
                ]
            }
        ]
    }
}
 */

[System.Serializable]
public class DependenciesData
{
    public Maps_Dependencies_Grid[] maps_dependencies_grid;
    public Maps_Dependencies_Tree[] maps_dependencies_tree;
}

[System.Serializable]
public class Maps_Dependencies_Grid
{
    public Mdg_Data[] mtg_data;
}

[System.Serializable]
public class Mdg_Data
{
    public string mdg_api_url;
    public int uptree_node;
    public int downtree_node;
    public int sibiling_node;
}

[System.Serializable]
public class Maps_Dependencies_Tree
{
    public Mdt_Data[] mdt_data;
}

[System.Serializable]
public class Mdt_Data
{
    public string title;
    public string key_findings;
    public string graph_type;
    public int no_of_levels;
    public Legend_Chart_Data[] legend_chart_data;
    public Legend_Tree_Node_Data[] legend_tree_node_data;
    public Legend_Tree_Edge_Data[] legend_tree_edge_data;
}

[System.Serializable]
public class Legend_Chart_Data
{
    public string group_name;
    public int group;
}

[System.Serializable]
public class Legend_Tree_Node_Data
{
    public string id;
    public string display_name;
    public int level;
    public int group;
}

[System.Serializable]
public class Legend_Tree_Edge_Data
{
    public string source;
    public string target;
}
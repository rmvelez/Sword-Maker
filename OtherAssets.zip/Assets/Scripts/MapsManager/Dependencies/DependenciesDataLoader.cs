using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class DependenciesDataLoader : MonoBehaviour
{
    public TextMeshPro display_name;

    public void UpdateDependenciesData(Legend_Tree_Node_Data legend_tree_node_data)
    {
        display_name.text = legend_tree_node_data.display_name;
    }
}

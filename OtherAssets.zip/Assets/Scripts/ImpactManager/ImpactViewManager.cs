using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class ImpactViewManager : MonoBehaviour
{
    public DataClass data;

    public GameObject impactCurrentGraphParent;
    public GameObject impactCurrentObjectParent;
    
    public GameObject impact30GraphParent;
    public GameObject impact30ObjectParent;

    public GameObject impact60GraphParent;
    public GameObject impact60ObjectParent;

    public GameObject impact90GraphParent;
    public GameObject impact90ObjectParent;

    public GameObject jobViewParent;
    public GameObject jobsParent;
    public GameObject businessFV;

    public GameObject impactView;
    public GameObject NoDataObject;
    public ImpactDataManager idm;

    public string selectedObjName;

    public WatchVoiceManager wvm;

    // reference to failed jobs
    //public MeshRenderer jobOne;
    //public MeshRenderer jobTwo;
    public GameObject jobOne;
    public GameObject jobTwo;

    // reference to orbs that can be grabbed on Impact SLA Screen
    
    public GameObject currentObj;
    public GameObject thirtyOneObj;
    public GameObject thirtyTwoObj;

    public GameObject sixtyOneObj;
    public GameObject sixtyTwoObj;
    public GameObject ninetyOneObj;
    public GameObject ninetyTwoObj;
    public GameObject ninetyThreeObj;

    // reference to orbs that are used to reference the location of the dock where the SLA Spheres can be placed
    
    public GameObject currentRef;
    public GameObject thirtyOneRef;
    public GameObject thirtyTwoRef;
    
    public GameObject sixtyOneRef;
    public GameObject sixtyTwoRef;
    public GameObject ninetyOneRef;
    public GameObject ninetyTwoRef;
    public GameObject ninetyThreeRef;

    public void UpdateObj(string name)
    {
        selectedObjName = name;
        int index = 0;
        string urltosend = "";
        for (int i = 0; i < data.ffData.faults_failed.Length; i++)
        {
            if (data.ffData.faults_failed[i].name == selectedObjName)
            {
                urltosend = data.ffData.faults_failed[i].sla_obj_url;
                urltosend = urltosend.Replace("/solutions", "");
                urltosend = data.configData.hostUrl + urltosend;
                //print(urltosend);
                break;
            }
        }
        idm.PopulateSLAData(urltosend);
    }

    public void ShowCurrent()
    {
        DeactivateImpacts();
        DeactivateViews();
        impactView.SetActive(true);
        currentObj.SetActive(true);
        currentRef.SetActive(true);
        if (data.impactSLAData.slacurrent != null)
        {
            if (data.icd.graphdata.Length >= 1)
            {
                impactCurrentGraphParent.SetActive(true);
                NoDataObject.SetActive(false);
            }
            else
            {
                impactCurrentGraphParent.SetActive(false);
            }
            
            if (data.impactSLAData.slacurrent.Length >= 1)
            {
                impactCurrentObjectParent.SetActive(true);
            }
            else
            {
                impactCurrentObjectParent.SetActive(false);
            }
        }
        else
        {
            NoDataObject.SetActive(true);
        }
    }

    public void Show30Min()
    {
        DeactivateImpacts();
        DeactivateViews();
        impactView.SetActive(true);
        thirtyOneObj.SetActive(true);
        thirtyOneRef.SetActive(true);
        thirtyTwoObj.SetActive(true);
        thirtyTwoRef.SetActive(true);
        if (data.impactSLAData.sla30min != null)
        {
            if (data.i3d.graphdata.Length >= 1)
            {
                impact30GraphParent.SetActive(true);
                NoDataObject.SetActive(false);
            }
            else
            {
                impact30GraphParent.SetActive(false);
            }

            if (data.impactSLAData.sla30min.Length >= 1)
            {
                impact30ObjectParent.SetActive(true);
            }
            else
            {
                impact30ObjectParent.SetActive(false);
            }
        }
        else
        {
            NoDataObject.SetActive(true);
        }
    }

    public void Show60Min()
    {
        DeactivateImpacts();
        DeactivateViews();
        impactView.SetActive(true);
        sixtyOneObj.SetActive(true);
        sixtyOneRef.SetActive(true);
        sixtyTwoObj.SetActive(true);
        sixtyTwoRef.SetActive(true);
        if (data.impactSLAData.sla60min != null)
        {
            if (data.i6d.graphdata.Length >= 1)
            {
                impact60GraphParent.SetActive(true);
                NoDataObject.SetActive(false);
            }
            else
            {
                impact60GraphParent.SetActive(false);
            }

            if (data.impactSLAData.sla60min.Length >= 1)
            {
                impact60ObjectParent.SetActive(true);
            }
            else
            {
                impact60ObjectParent.SetActive(false);
            }
        }
        else
        {
            NoDataObject.SetActive(true);
        }
    }

    public void Show90Min()
    {
        DeactivateImpacts();
        DeactivateViews();
        impactView.SetActive(true);
        ninetyOneObj.SetActive(true);
        ninetyOneRef.SetActive(true);
        ninetyTwoObj.SetActive(true);
        ninetyTwoRef.SetActive(true);
        ninetyThreeObj.SetActive(true);
        ninetyThreeRef.SetActive(true);
        if (data.impactSLAData.sla90min != null)
        {
            if (data.i9d.graphdata.Length >= 1)
            {
                impact90GraphParent.SetActive(true);
                NoDataObject.SetActive(false);
            }
            else
            {
                impact90GraphParent.SetActive(false);
            }

            if (data.impactSLAData.sla90min.Length >= 1)
            {
                impact90ObjectParent.SetActive(true);
            }
            else
            {
                impact90ObjectParent.SetActive(false);
            }
        }
        else
        {
            NoDataObject.SetActive(true);
        }
    }

    public void ShowJobView()
    {
        DeactivateImpacts();
        DeactivateViews();
        jobViewParent.SetActive(true);
        jobsParent.SetActive(true);
    }

    public void DeactivateViews()
    {
        impactView.SetActive(false);
        jobsParent.SetActive(false);
        jobViewParent.SetActive(false);
        businessFV.SetActive(false);
        //jobOne.enabled = false;
        //jobTwo.enabled = false;
        jobOne.SetActive(false);
        jobTwo.SetActive(false);
    }
    public void DeactivateImpacts()
    {
        impactCurrentGraphParent.SetActive(false);
        impactCurrentObjectParent.SetActive(false);
        currentObj.SetActive(false);
        currentRef.SetActive(false);
        

        impact30GraphParent.SetActive(false);
        impact30ObjectParent.SetActive(false);
        thirtyOneObj.SetActive(false);
        thirtyOneRef.SetActive(false);
        thirtyTwoObj.SetActive(false);
        thirtyTwoRef.SetActive(false);
        

        impact60GraphParent.SetActive(false);
        impact60ObjectParent.SetActive(false);
        sixtyOneObj.SetActive(false);
        sixtyOneRef.SetActive(false);
        sixtyTwoObj.SetActive(false);
        sixtyTwoRef.SetActive(false);

        impact90GraphParent.SetActive(false);
        impact90ObjectParent.SetActive(false);
        ninetyOneObj.SetActive(false);
        ninetyOneRef.SetActive(false);
        ninetyTwoObj.SetActive(false);
        ninetyTwoRef.SetActive(false);
        ninetyThreeObj.SetActive(false);
        ninetyThreeRef.SetActive(false);
    }

    public void SpeakText(TextMeshPro t)
    {
        //print(t.text.ToString());
        wvm.Parsetext(t.text.ToString());
    }

}

using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Networking;

public class ImpactDataManager : MonoBehaviour
{
    public DataClass dataClass;
    public ImpactSLAData isd;

    public TextMeshPro textCurrent;
    public TextMeshPro text30Min;
    public TextMeshPro text60Min;
    public TextMeshPro text90Min;

    public ImpactCurrentGraphData icd;
    public Impact30GraphData i3d;
    public Impact60GraphData i6d;
    public Impact90GraphData i9d;

    public ImpactGraphPopulator igmc;
    public ImpactGraphPopulator3 igm3;
    public ImpactGraphPopulator6 igm6;
    public ImpactGraphPopulator9 igm9;

    public ImpactObjectManager iomc;
    public ImpactObjectManager iom3;
    public ImpactObjectManager iom6;
    public ImpactObjectManager iom9;

    public TextMeshPro status;
    public TextMeshPro faultTime;
    public TextMeshPro desiredEndTime;

    public TimeConverter tt;
    public void PopulateSLAData(string url)
    {
        StartCoroutine(RequestData(url));
    }

    public IEnumerator RequestData(string apiRequestUrl)
    {
        UnityWebRequest unityWebRequest = new UnityWebRequest(apiRequestUrl, "Get");
        unityWebRequest.downloadHandler = new DownloadHandlerBuffer();

        yield return unityWebRequest.SendWebRequest();

        if (!unityWebRequest.isNetworkError)
        {
            ProcessResponseData(unityWebRequest.downloadHandler.text);
        }
        else
        {
            Debug.Log("Error While Sending: " + unityWebRequest.error);
        }

    }

    private void ProcessResponseData(string data)
    {
        isd = JsonUtility.FromJson<ImpactSLAData>(data);
        dataClass.setImpactSLAData(isd);
        //print(isd.slaTitles.Length);
        if (isd.slaTitles.Length > 1){
            for(int i =0;i< isd.slaTitles.Length; i++)
            {
                if(isd.slaTitles[i].subtitle == "0")
                {
                    //textCurrent.text = isd.slaTitles[i].title;
                    if (isd.slacurrent != null)
                    {
                        iomc.ResetObjects();
                        iomc.PopulateObjectsCurrent(isd.slacurrent);
                    }
                    else
                    {
                        iomc.ResetObjects();
                    }
                }
                else if(isd.slaTitles[i].subtitle == "30")
                {
                    //text30Min.text = isd.slaTitles[i].title;
                    if (isd.sla30min != null)
                    {
                        iom3.ResetObjects();
                        iom3.PopulateObjects30(isd.sla30min);
                    }
                    else
                    {
                        iom3.ResetObjects();
                    }
                }
                else if (isd.slaTitles[i].subtitle == "60")
                {
                    //text60Min.text = isd.slaTitles[i].title;
                    if (isd.sla60min != null)
                    {
                        iom6.ResetObjects();
                        iom6.PopulateObjects60(isd.sla60min);
                    }
                    else
                    {
                        iom6.ResetObjects();
                    }
                }
                else if(isd.slaTitles[i].subtitle == "90")
                {
                    //text90Min.text = isd.slaTitles[i].title;
                    if (isd.sla90min != null)
                    {
                        iom9.ResetObjects();
                        iom9.PopulateObjects90(isd.sla90min);
                    }
                    else
                    {
                        iom9.ResetObjects();
                    }
                }
            }
        }

        ProcessGraphData();
    }

    public void ProcessGraphData()
    {
        string currenturl = dataClass.configData.hostUrl + isd.api_urls.graph_current_url;
        string url30 = dataClass.configData.hostUrl + isd.api_urls.graph_30_url;
        string url60 = dataClass.configData.hostUrl + isd.api_urls.graph_60_url;
        string url90 = dataClass.configData.hostUrl + isd.api_urls.graph_90_url;
        StartCoroutine(RequestCurrentData(currenturl));
        StartCoroutine(Request30Data(url30));
        StartCoroutine(Request60Data(url60));
        StartCoroutine(Request90Data(url90));
    }

    public IEnumerator RequestCurrentData(string apiRequestUrl)
    {
        UnityWebRequest unityWebRequest = new UnityWebRequest(apiRequestUrl, "Get");
        unityWebRequest.downloadHandler = new DownloadHandlerBuffer();

        yield return unityWebRequest.SendWebRequest();

        if (!unityWebRequest.isNetworkError)
        {
            ProcessResponseDataCurrent(unityWebRequest.downloadHandler.text);
        }
        else
        {
            Debug.Log("Error While Sending: " + unityWebRequest.error);
        }

    }

    private void ProcessResponseDataCurrent(string data)
    {
        icd = JsonUtility.FromJson<ImpactCurrentGraphData>(data);
        dataClass.setImpactCurrentGraphData(icd);
        status.text = icd.graphdata[0].status;
        faultTime.text = tt.ConvertToIST(icd.graphdata[0].startTime).ToString();
        desiredEndTime.text = tt.ConvertToIST(icd.graphdata[0].desiredEndTime).ToString();
        if (icd.graphdata != null && icd.graphdata.Length >= 1)
        {
            igmc.PopulateCurrent(icd);
        }
        else
        {
            igmc.ResetChart();
        }

    }

    public IEnumerator Request30Data(string apiRequestUrl)
    {
        UnityWebRequest unityWebRequest = new UnityWebRequest(apiRequestUrl, "Get");
        unityWebRequest.downloadHandler = new DownloadHandlerBuffer();

        yield return unityWebRequest.SendWebRequest();

        if (!unityWebRequest.isNetworkError)
        {
            ProcessResponseData30(unityWebRequest.downloadHandler.text);
        }
        else
        {
            Debug.Log("Error While Sending: " + unityWebRequest.error);
        }

    }

    private void ProcessResponseData30(string data)
    {
        i3d = JsonUtility.FromJson<Impact30GraphData>(data);
        dataClass.setImpact30GraphData(i3d);
        if (i3d.graphdata != null && i3d.graphdata.Length >= 1)
        {
            //igm3.ResetChart();
            igm3.Populate30Min(i3d);
        }
        else
        {
            igm3.ResetChart();
        }

    }

    public IEnumerator Request60Data(string apiRequestUrl)
    {
        UnityWebRequest unityWebRequest = new UnityWebRequest(apiRequestUrl, "Get");
        unityWebRequest.downloadHandler = new DownloadHandlerBuffer();

        yield return unityWebRequest.SendWebRequest();

        if (!unityWebRequest.isNetworkError)
        {
            ProcessResponseData60(unityWebRequest.downloadHandler.text);
        }
        else
        {
            Debug.Log("Error While Sending: " + unityWebRequest.error);
        }

    }

    private void ProcessResponseData60(string data)
    {
        i6d = JsonUtility.FromJson<Impact60GraphData>(data);
        dataClass.setImpact60GraphData(i6d);
        if (i6d.graphdata != null && i6d.graphdata.Length >= 1)
        {
            //igm6.ResetChart();
            igm6.Populate60Min(i6d);
        }
        else
        {
            igm6.ResetChart();
        }

    }

    public IEnumerator Request90Data(string apiRequestUrl)
    {
        UnityWebRequest unityWebRequest = new UnityWebRequest(apiRequestUrl, "Get");
        unityWebRequest.downloadHandler = new DownloadHandlerBuffer();

        yield return unityWebRequest.SendWebRequest();

        if (!unityWebRequest.isNetworkError)
        {
            ProcessResponseData90(unityWebRequest.downloadHandler.text);
        }
        else
        {
            Debug.Log("Error While Sending: " + unityWebRequest.error);
        }

    }

    private void ProcessResponseData90(string data)
    {
        i9d = JsonUtility.FromJson<Impact90GraphData>(data);
        dataClass.setImpact90GraphData(i9d);
        if (i9d.graphdata != null && i9d.graphdata.Length >= 1)
        {
            //igm9.ResetChart();
            igm9.Populate90Min(i9d);
        }
        else
        {
            igm9.ResetChart();
        }
            
    }
}

using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class ImpactGraphPopulator6 : MonoBehaviour
{
    public DataClass dataclass;
    public GameObject GraphParent;
    public GameObject ChartObj;
    public GameObject TextObj;
    public GameObject TextObjX;
    public List<Vector3> chartObjpos;
    public List<Vector3> txtObjspos;
    public List<Vector3> txtXObjspos;
    public List<GameObject> chartObjs;
    public List<GameObject> txtObjs;
    public TimeConverter tc;
    public List<GameObject> txtXObj;

    public GameObject desiredChartObj;
    public List<Vector3> desiredChartObjPos;
    public List<GameObject> desiredChartObjs;
    public GameObject startline;
    public ImpactDataManager idm;

    public int upcount = 0;
    public int length;
    public int limit;
    public int togglecount;
    void Start()
    {
        togglecount = 0;
    }

    public void ShowDesiredState()
    {
        if (togglecount == 0)
        {
            ActivateDesiredStates();
            togglecount = 1;
        }
        else
        {
            DeactivateDesiredStates();
            togglecount = 0;
        }
    }

    public void ActivateDesiredStates()
    {
        for (int i = 0; i < chartObjs.Count; i++)
        {
            desiredChartObjs[i].SetActive(true);

        }
    }

    public void DeactivateDesiredStates()
    {
        for (int i = 0; i < chartObjs.Count; i++)
        {
            desiredChartObjs[i].SetActive(false);
        }
    }

    public void AnimateObjs()
    {
        foreach (GameObject g in chartObjs)
        {
            GameObject bar = g.GetComponent<ChartObjManager>().Chartbar;
            Vector3 org = bar.transform.localScale;
            bar.transform.localScale = new Vector3(0, org.y, org.z);
            float scale = g.GetComponent<ChartObjManager>().scaleX;
            LeanTween.scale(bar, new Vector3(scale, org.y, org.z), 1f);
        }
        foreach (GameObject g in desiredChartObjs)
        {
            GameObject bar = g.GetComponent<ChartObjManager>().Chartbar;
            Vector3 org = bar.transform.localScale;
            bar.transform.localScale = new Vector3(0, org.y, org.z);
            float scale = g.GetComponent<ChartObjManager>().scaleX;
            LeanTween.scale(bar, new Vector3(scale, org.y, org.z), 1f);
        }
    }

    public void AnimateObject(GameObject g)
    {
        GameObject bar = g.GetComponent<ChartObjManager>().Chartbar;
        Vector3 org = bar.transform.localScale;
        bar.transform.localScale = new Vector3(0, org.y, org.z);
        float scale = g.GetComponent<ChartObjManager>().scaleX;
        LeanTween.scale(bar, new Vector3(scale, org.y, org.z), 1f);
    }

    public void Populate60Min(Impact60GraphData i6d)
    {
        ResetChart();
        length = i6d.graphdata.Length - 1;
        limit = i6d.graphdata.Length;
        Vector3 objposition = ChartObj.transform.position;
        Vector3 txtPosition = TextObj.transform.position;
        Vector3 txtPositionX = TextObjX.transform.position;
        GameObject s;
        Vector3 desiredObjPosition = desiredChartObj.transform.position;
        double offsetX = 0f;
        float offX = 0f;
        double scaleOffset = 0f;
        float scaleOff = 0f;
        for (int i = 0; i < i6d.graphdata.Length; i++)
        {
            scaleOffset = (i6d.graphdata[i].endTime - i6d.graphdata[i].startTime) / 3600000;
            scaleOff = (float)scaleOffset;
            if (i6d.graphdata[i].desiredStartTime > 0f)
            {
                offsetX = (i6d.graphdata[i].startTime - i6d.graphdata[i].desiredStartTime) / 3600000;
                offX = (float)offsetX;
            }
            else
            {
                offX = 0f;
            }
            if (i == 0)
            {
                objposition = new Vector3(objposition.x + (offX / 10) - 0.02f, objposition.y, objposition.z);
                s = Instantiate(startline, new Vector3(objposition.x, startline.transform.position.y, startline.transform.position.z), Quaternion.identity);
                s.transform.SetParent(GraphParent.transform);
                s.SetActive(true);
            }
            GameObject go = Instantiate(ChartObj, objposition, Quaternion.identity);
            go.transform.SetParent(GraphParent.transform);
            go.name = i6d.graphdata[i].entityName;
            go.GetComponent<ChartObjManager>().setScale(scaleOff);
            go.GetComponent<ChartObjManager>().UpdateObj(i6d.graphdata[i]);
            chartObjpos.Add(objposition);
            chartObjs.Add(go);
            objposition = objposition - new Vector3(0, 0.15f, 0);
            objposition = new Vector3((scaleOff / 10f) + objposition.x - 0.02f, objposition.y, objposition.z);

            if (i6d.graphdata[i].desiredStartTime > 0)
            {
                scaleOffset = (i6d.graphdata[i].desiredEndTime - i6d.graphdata[i].desiredStartTime) / 3600000;
                scaleOff = (float)scaleOffset;
                offsetX = (i6d.graphdata[i].startTime - i6d.graphdata[i].desiredStartTime) / 3600000;
                offX = (float)offsetX;
            }
            else
            {
                scaleOff = 0f;
                offX = 0f;
            }
            //print("Off x " + offX);
            desiredObjPosition = new Vector3(go.transform.position.x - (offX / 10) - 0.02f, desiredObjPosition.y, desiredObjPosition.z);

            GameObject dobj = Instantiate(desiredChartObj, desiredObjPosition, Quaternion.identity);
            dobj.transform.SetParent(GraphParent.transform);
            dobj.name = i6d.graphdata[i].entityName;
            dobj.GetComponent<ChartObjManager>().setScale(scaleOff);
            dobj.GetComponent<ChartObjManager>().UpdateObj(i6d.graphdata[i]);
            desiredChartObjPos.Add(desiredObjPosition);
            desiredObjPosition = desiredObjPosition - new Vector3(0, 0.15f, 0);
            dobj.transform.SetParent(go.transform);
            desiredChartObjs.Add(dobj);

            GameObject txt = Instantiate(TextObj, txtPosition, Quaternion.identity);
            txt.transform.SetParent(GraphParent.transform);
            txt.GetComponentInChildren<TextMeshPro>().text = i6d.graphdata[i].entityName;

            txtObjspos.Add(txtPosition);
            txtPosition = txtPosition - new Vector3(0, 0.15f, 0);
            txtObjs.Add(txt);

            if (i % 2 == 0)
            {
                GameObject txtX = Instantiate(TextObjX, txtPositionX, Quaternion.identity);
                txtX.transform.SetParent(GraphParent.transform);
                txtX.GetComponentInChildren<TextMeshPro>().text = tc.ConvertToIST(i6d.graphdata[i].startTime).ToString();
                txtPositionX = txtPositionX + new Vector3(0.25f, 0, 0);
                txtXObjspos.Add(txtPositionX);
                txtX.SetActive(true);
                txtXObj.Add(txtX);
            }

            if (i <= 5)
            {
                go.SetActive(true);
                txt.SetActive(true);
            }
            else
            {
                go.SetActive(false);
                txt.SetActive(false);
            }
        }
    }

    public void ScrollUp()
    {
        if (upcount < length)
        {
            ActivateObj(upcount + 6);
            DeactivateObj(upcount);
            upcount++;

            foreach (GameObject g in chartObjs)
            {
                Vector3 initPos = g.transform.position;
                g.transform.position = initPos + new Vector3(0, 0.15f, 0);
            }
            foreach (GameObject t in txtObjs)
            {
                Vector3 initPos = t.transform.position;
                t.transform.position = initPos + new Vector3(0, 0.15f, 0);
            }
        }
    }

    public void ScrollDown()
    {
        if (upcount > 0)
        {
            ActivateObj(upcount - 1);
            DeactivateObj((upcount - 1) + 6);
            upcount--;

            foreach (GameObject g in chartObjs)
            {
                Vector3 initPos = g.transform.position;
                g.transform.position = initPos - new Vector3(0, 0.15f, 0);
            }
            foreach (GameObject t in txtObjs)
            {
                Vector3 initPos = t.transform.position;
                t.transform.position = initPos - new Vector3(0, 0.15f, 0);
            }
        }
    }

    public void ActivateObj(int index)
    {
        if (index < limit && index >= 0)
        {
            print(chartObjs.Count);
            chartObjs[index].SetActive(true);
            AnimateObject(chartObjs[index]);
            txtObjs[index].SetActive(true);
        }
    }

    public void DeactivateObj(int index)
    {
        if (index < limit && index >= 0)
        {
            chartObjs[index].SetActive(false);
            txtObjs[index].SetActive(false);
        }
    }
    public void ResetChart()
    {
        //print("reset called 6");
        try
        {
            if (desiredChartObjs.Count > 0)
            {
                /*
                for (int i = desiredChartObjs.Count - 1; i >= 0; i++)
                {
                    Destroy(desiredChartObjs[i]);
                    desiredChartObjs.RemoveAt(i);
                    //desiredChartObjs[i].SetActive(false);
                    //desiredChartObjs.Remove(desiredChartObjs[i]);
                }
                */
                desiredChartObjs.Clear();
                //print("DesriedChartObj count " + desiredChartObjs.Count);
            }
        }
        catch (ArgumentOutOfRangeException e)
        {
            print("desired chart obj " + e);
        }
        try
        {
            if (chartObjs.Count > 0)
            {
                for (int i = chartObjs.Count - 1; i >= 0; i--)
                {
                    Destroy(chartObjs[i]);
                    chartObjs.RemoveAt(i);
                    //chartObjs[i].SetActive(false);
                    //chartObjs.Remove(chartObjs[i]);
                }
                chartObjs.Clear();
            }
        }
        catch (ArgumentOutOfRangeException e)
        {
            print("chart objs " + e);
        }
        try
        {
            if (txtObjs.Count > 0)
            {
                for (int i = txtObjs.Count - 1; i >= 0; i--)
                {
                    Destroy(txtObjs[i]);
                    txtObjs.RemoveAt(i);
                    //txtObjs[i].SetActive(false);
                    //txtObjs.Remove(txtObjs[i]);
                }
                txtObjs.Clear();
            }
        }
        catch (ArgumentOutOfRangeException e)
        {
            print("txt objs " + e);
        }
        try
        {
            if (txtXObj.Count > 0)
            {
                for (int i = txtXObj.Count - 1; i >= 0; i--)
                {
                    Destroy(txtXObj[i]);
                    txtXObj.RemoveAt(i);
                    //txtXObj[i].SetActive(false);
                    //txtXObj.Remove(txtXObj[i]);
                }
                txtXObj.Clear();
            }
        }
        catch (ArgumentOutOfRangeException e)
        {
            print("txt x obj " + e);
        }
        try
        {
            if (chartObjpos.Count > 0)
            {
                for (int i = chartObjpos.Count - 1; i >= 0; i--)
                {
                    chartObjpos.RemoveAt(i);
                    //chartObjpos.Remove(chartObjpos[i]);
                }
                chartObjpos.Clear();
            }
        }
        catch (ArgumentOutOfRangeException e)
        {
            print("chart obj pos " + e);
        }
        try
        {
            if (txtObjspos.Count > 0)
            {
                for (int i = txtObjspos.Count - 1; i >= 0; i--)
                {
                    txtObjspos.RemoveAt(i);
                    //txtObjspos.Remove(txtObjspos[i]);
                }
                txtObjspos.Clear();
            }
        }
        catch (ArgumentOutOfRangeException e)
        {
            print("txt obj pos " + e);
        }
        try
        {
            if (txtXObjspos.Count > 0)
            {
                for (int i = txtXObjspos.Count - 1; i >= 0; i--)
                {
                    txtXObjspos.RemoveAt(i);
                    //txtXObjspos.Remove(txtXObjspos[i]);
                }
                txtXObjspos.Clear();
            }
        }
        catch (ArgumentOutOfRangeException e)
        {
            print("txt X obj pos " + e);
        }
        try
        {
            if (desiredChartObjPos.Count > 0)
            {
                for (int i = desiredChartObjPos.Count - 1; i >= 0; i--)
                {
                    desiredChartObjPos.RemoveAt(i);
                    //txtXObjspos.Remove(txtXObjspos[i]);
                }
                desiredChartObjPos.Clear();
            }
        }
        catch (ArgumentOutOfRangeException e)
        {
            print("desired Chart Obj Pos " + e);
        }
        //print("reset end 6");
    }

}

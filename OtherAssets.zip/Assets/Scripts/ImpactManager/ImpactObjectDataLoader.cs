using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
public class ImpactObjectDataLoader : MonoBehaviour
{
    public TextMeshPro name;
    public TextMeshPro type;
    public TextMeshPro slatype;
    public TextMeshPro observedvalue;
    public TextMeshPro slavalue;

    public void UpdateSLAObjectText_Current(SLACurrent data)
    {
        name.text = data.name;
        type.text = data.type;
        slatype.text = data.slatype;
        observedvalue.text = data.observedvalue;
        slavalue.text = data.slavalue;
    }

    public void UpdateSLAObjectText_30(SLA30Min data)
    {
        name.text = data.name;
        type.text = data.type;
        slatype.text = data.slatype;
        observedvalue.text = data.observedvalue;
        slavalue.text = data.slavalue;
    }

    public void UpdateSLAObjectText_60(SLA60Min data)
    {
        name.text = data.name;
        type.text = data.type;
        slatype.text = data.slatype;
        observedvalue.text = data.observedvalue;
        slavalue.text = data.slavalue;
    }

    public void UpdateSLAObjectText_90(SLA90Min data)
    {
        name.text = data.name;
        type.text = data.type;
        slatype.text = data.slatype;
        observedvalue.text = data.observedvalue;
        slavalue.text = data.slavalue;
    }



}

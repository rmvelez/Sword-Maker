using Microsoft.MixedReality.Toolkit.Input;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ImpactChartObjectTapController : MonoBehaviour, IMixedRealityFocusHandler, IMixedRealityPointerHandler
{
    public GameObject hoverObject;
    public void OnFocusEnter(FocusEventData eventData)
    {
        hoverObject.SetActive(true);
        //throw new System.NotImplementedException();
    }

    public void OnFocusExit(FocusEventData eventData)
    {
        hoverObject.SetActive(false);
        //throw new System.NotImplementedException();
    }

    public void OnPointerClicked(MixedRealityPointerEventData eventData)
    {
     
    }

    public void OnPointerDown(MixedRealityPointerEventData eventData)
    {

        //throw new System.NotImplementedException();
    }

    public void OnPointerDragged(MixedRealityPointerEventData eventData)
    {

        //throw new System.NotImplementedException();
    }

    public void OnPointerUp(MixedRealityPointerEventData eventData)
    {

        //throw new System.NotImplementedException();
    }
}

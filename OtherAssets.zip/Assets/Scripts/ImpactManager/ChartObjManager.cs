using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class ChartObjManager : MonoBehaviour
{
    public GameObject Chartbar;
    public SpriteRenderer spriteToRender;
    public Renderer materialToRender;
    public Material downstreamMat;
    public Material impactedMat;
    public Material failureMat;
    public Sprite downstreamSprite;
    public Sprite impactedSprite;
    public Sprite failureSprite;
    private DataClass dataClass;
    public TextMeshPro jobname;
    public TextMeshPro startTime;
    public TextMeshPro endTime;
    public TextMeshPro bpName;
    public float scaleX;
    private System.DateTime stdDateTime;
    public int state;
    public GameObject pointerCube;
    public GameObject SLADefinedText;
    public GameObject SLADefinedValue;
    public void Awake()
    {
        
    }
    public void Start()
    {
        
    }
    public void setScale(float val)
    {
        scaleX = val;
        LeanTween.scale(Chartbar, new Vector3(val, Chartbar.transform.localScale.y, Chartbar.transform.localScale.z), 1f);
    }
    public void UpdateObj(GraphData data)
    {
        dataClass = GameObject.FindGameObjectWithTag("Data").GetComponent<DataClass>();
        if (dataClass.impactSLAData.slaTitles.Length > 1)
        {
            string processName = data.entityName;
            for (int i = 0; i < dataClass.impactSLAData.sla90min.Length; i++)
            {
                if (dataClass.impactSLAData.sla90min[i].name == processName)
                {
                    //print(processName);
                    SLADefinedValue.GetComponent<TextMeshPro>().text = dataClass.impactSLAData.sla90min[i].slavalue;
                }
            }
            if (state == 0)
            {
                stdDateTime = new System.DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);
                if (data.status == "Failed Job")
                {
                    //print("Checked");
                    materialToRender.material = failureMat;
                    spriteToRender.sprite = failureSprite;
                    pointerCube.SetActive(false);
                }
                else if (data.status == "Downstream Jobs")
                {
                    materialToRender.material = downstreamMat;
                    spriteToRender.sprite = downstreamSprite;
                }
                else if (data.status == "Impacted SLA")
                {
                    materialToRender.material = impactedMat;
                    spriteToRender.sprite = impactedSprite;
                    SLADefinedText.SetActive(true);
                    SLADefinedValue.SetActive(true);
                }

                jobname.text = data.entityName;
                startTime.text = stdDateTime.AddMilliseconds(data.startTime).ToLocalTime().ToString();
                endTime.text = stdDateTime.AddMilliseconds(data.endTime).ToLocalTime().ToString();
            }
            else
            {
                stdDateTime = new System.DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);
                jobname.text = data.entityName;
                startTime.text = stdDateTime.AddMilliseconds(data.desiredStartTime).ToLocalTime().ToString();
                endTime.text = stdDateTime.AddMilliseconds(data.desiredEndTime).ToLocalTime().ToString();

                if (data.status == "Impacted SLA")
                {
                    SLADefinedText.SetActive(true);
                    SLADefinedValue.SetActive(true);
                }
                else
                {
                    SLADefinedText.SetActive(false);
                    SLADefinedValue.SetActive(false);
                    SLADefinedValue.SetActive(false);
                }
            }
        }
    }
}

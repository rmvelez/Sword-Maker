using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ImpactObjectManager : MonoBehaviour
{
    public ImpactSLAData impactSLAData;
    public GameObject[] slaObjects;
    public int code = 0;
    public void PopulateObjectsCurrent(SLACurrent[] slacurrent)
    {
        for (int i = 0; i < slacurrent.Length; i++)
        {
            slaObjects[i].SetActive(true);
            slaObjects[i].GetComponentInChildren<ImpactObjectDataLoader>().UpdateSLAObjectText_Current(slacurrent[i]);
        }
    }

    public void PopulateObjects30(SLA30Min[] sla30min)
    {
        for (int i = 0; i < sla30min.Length; i++)
        {
            slaObjects[i].SetActive(true);
            slaObjects[i].GetComponentInChildren<ImpactObjectDataLoader>().UpdateSLAObjectText_30(sla30min[i]);
        }
    }

    public void PopulateObjects60(SLA60Min[] sla60min)
    {
        for (int i = 0; i < sla60min.Length; i++)
        {
            slaObjects[i].SetActive(true);
            slaObjects[i].GetComponentInChildren<ImpactObjectDataLoader>().UpdateSLAObjectText_60(sla60min[i]);
        }
    }

    public void PopulateObjects90(SLA90Min[] sla90min)
    {
        for (int i = 0; i < sla90min.Length; i++)
        {
            slaObjects[i].SetActive(true);
            slaObjects[i].GetComponentInChildren<ImpactObjectDataLoader>().UpdateSLAObjectText_90(sla90min[i]);
        }
    }

    public void ResetObjects()
    {
        for(int i = 0; i < slaObjects.Length; i++)
        {
            slaObjects[i].SetActive(false);
        }
    }


}

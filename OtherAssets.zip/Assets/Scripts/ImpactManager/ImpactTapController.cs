using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using Microsoft.MixedReality.Toolkit.Input;

public class ImpactTapController : MonoBehaviour, IMixedRealityFocusHandler, IMixedRealityPointerHandler
{
    public GameObject hoverObject;
    
    public void OnTriggerEnter(Collider other)
    {
        hoverObject.SetActive(false);

    }
    public void OnTriggerStay(Collider other)
    {
        hoverObject.SetActive(false);
    }

    public void OnTriggerExit(Collider other)
    {
        hoverObject.SetActive(true);
    }
    public void OnFocusEnter(FocusEventData eventData)
    {

        //throw new System.NotImplementedException();
    }

    public void OnFocusExit(FocusEventData eventData)
    {

        //throw new System.NotImplementedException();
    }

    public void OnPointerClicked(MixedRealityPointerEventData eventData)
    {

    }

    public void OnPointerDown(MixedRealityPointerEventData eventData)
    {

        //throw new System.NotImplementedException();
    }

    public void OnPointerDragged(MixedRealityPointerEventData eventData)
    {

        //throw new System.NotImplementedException();
    }

    public void OnPointerUp(MixedRealityPointerEventData eventData)
    {

        //throw new System.NotImplementedException();
    }

}

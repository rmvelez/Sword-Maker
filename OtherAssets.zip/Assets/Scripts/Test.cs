using Microsoft.MixedReality.Toolkit.Audio;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Test : MonoBehaviour
{
    public TextToSpeech textToSpeech;
    public string speakText;
    // Start is called before the first frame update
    void Start()
    {

    }

    public void talk()
    {
        var msg = string.Format(speakText,textToSpeech.Voice.ToString());

        textToSpeech.StartSpeaking(msg);
        Debug.Log("TextSpoken");
    }
    // Update is called once per frame
    void Update()
    {
        
    }
}
